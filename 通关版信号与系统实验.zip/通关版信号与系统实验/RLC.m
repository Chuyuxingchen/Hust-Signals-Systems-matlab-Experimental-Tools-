function varargout = RLC(varargin)
% RLC MATLAB code for RLC.fig
%      RLC, by itself, creates a new RLC or raises the existing
%      singleton*.
%
%      H = RLC returns the handle to a new RLC or the handle to
%      the existing singleton*.
%
%      RLC('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in RLC.M with the given input arguments.
%
%      RLC('Property','Value',...) creates a new RLC or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before RLC_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to RLC_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help RLC

% Last Modified by GUIDE v2.5 18-May-2025 09:06:12

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @RLC_OpeningFcn, ...
                   'gui_OutputFcn',  @RLC_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before RLC is made visible.
function RLC_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to RLC (see VARARGIN)

% Choose default command line output for RLC
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes RLC wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = RLC_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbuttonRLC_1.
function pushbuttonRLC_1_Callback(hObject, eventdata, handles)
try
    [t, y] = calculate_response(handles, 'impulse');
    if isempty(t) || isempty(y)
        errordlg('无有效计算结果');
        return;
    end
    axes(handles.axes1);
    plot(t, y, 'b', 'LineWidth', 1.5);
    grid on; title('冲激响应'); xlabel('时间 (s)'); ylabel('幅度');
catch ME
    errordlg(['绘图错误: ' ME.message]);
end
% hObject    handle to pushbuttonRLC_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbuttonRLC_2.
function pushbuttonRLC_2_Callback(hObject, eventdata, handles)
try
    [t, y] = calculate_response(handles, 'zero_input');
    if isempty(t) || isempty(y)
        errordlg('无有效计算结果');
        return;
    end
    axes(handles.axes2);
    plot(t, y, 'r', 'LineWidth', 1.5);
    grid on; title('零输入响应'); xlabel('时间 (s)'); ylabel('幅度');
catch ME
    errordlg(['绘图错误: ' ME.message]);
end
% hObject    handle to pushbuttonRLC_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbuttonRLC_3.
function pushbuttonRLC_3_Callback(hObject, eventdata, handles)
try
    [t, y] = calculate_response(handles, 'zero_state');
    if isempty(t) || isempty(y)
        errordlg('无有效计算结果');
        return;
    end
    axes(handles.axes3);
    plot(t, y, 'g', 'LineWidth', 1.5);
    grid on; title('零状态响应'); xlabel('时间 (s)'); ylabel('幅度');
catch ME
    errordlg(['绘图错误: ' ME.message]);
end
% hObject    handle to pushbuttonRLC_3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbuttonRLC_4.
function pushbuttonRLC_4_Callback(hObject, eventdata, handles)
try
    [t, y] = calculate_response(handles, 'full');
    if isempty(t) || isempty(y)
        errordlg('无有效计算结果');
        return;
    end
    axes(handles.axes4);
    plot(t, y, 'm', 'LineWidth', 1.5);
    grid on; title('全响应'); xlabel('时间 (s)'); ylabel('幅度');
catch ME
    errordlg(['绘图错误: ' ME.message]);
end
% hObject    handle to pushbuttonRLC_4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton_back.
function pushbutton_back_Callback(hObject, eventdata, handles)
close(gcf);
mystart;
% hObject    handle to pushbutton_back (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in popupmenu_response.
function popupmenu_response_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_response (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_response contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_response


% --- Executes during object creation, after setting all properties.
function popupmenu_response_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_response (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu_excitation.
function popupmenu_excitation_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_excitation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_excitation contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_excitation


% --- Executes during object creation, after setting all properties.
function popupmenu_excitation_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_excitation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- 输入验证
function editR_Callback(hObject, ~, handles)
val = str2double(get(hObject,'String'));
if isnan(val) || val < 0
    set(hObject, 'BackgroundColor', [1 0.8 0.8]);
else
    set(hObject, 'BackgroundColor', 'white');
end
% hObject    handle to editR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editR as text
%        str2double(get(hObject,'String')) returns contents of editR as a double


% --- Executes during object creation, after setting all properties.
function editR_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editC_Callback(hObject, eventdata, handles)
val = str2double(get(hObject,'String'));
if isnan(val) || val < 0
    set(hObject, 'BackgroundColor', [1 0.8 0.8]);
else
    set(hObject, 'BackgroundColor', 'white');
end
% hObject    handle to editC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editC as text
%        str2double(get(hObject,'String')) returns contents of editC as a double


% --- Executes during object creation, after setting all properties.
function editC_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editL_Callback(hObject, eventdata, handles)
val = str2double(get(hObject,'String'));
if isnan(val) || val < 0
    set(hObject, 'BackgroundColor', [1 0.8 0.8]);
else
    set(hObject, 'BackgroundColor', 'white');
end
% hObject    handle to editL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editL as text
%        str2double(get(hObject,'String')) returns contents of editL as a double


% --- Executes during object creation, after setting all properties.
function editL_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editV0_Callback(hObject, eventdata, handles)
val = str2double(get(hObject,'String'));
if isnan(val)
    set(hObject, 'BackgroundColor', [1 0.8 0.8]);
else
    set(hObject, 'BackgroundColor', 'white');
end


% hObject    handle to editV0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editV0 as text
%        str2double(get(hObject,'String')) returns contents of editV0 as a double


% --- Executes during object creation, after setting all properties.
function editV0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editV0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editI0_Callback(hObject, eventdata, handles)
val = str2double(get(hObject,'String'));
if isnan(val)
    set(hObject, 'BackgroundColor', [1 0.8 0.8]);
else
    set(hObject, 'BackgroundColor', 'white');
end
% hObject    handle to editI0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editI0 as text
%        str2double(get(hObject,'String')) returns contents of editI0 as a double


% --- Executes during object creation, after setting all properties.
function editI0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editI0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
%=====================================================================

% --- Executes just before RLC_GUI is made visible.
function RLC_GUI_OpeningFcn(hObject, ~, handles, varargin)
handles.output = hObject;
guidata(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = RLC_GUI_OutputFcn(~, ~, handles) 
varargout{1} = handles.output;

% ======================== 核心计算函数 ============================
function [t, y] = calculate_response(handles, response_type)
% 获取参数
R = str2double(get(handles.editR, 'String'));
L = str2double(get(handles.editL, 'String'));
C = str2double(get(handles.editC, 'String'));
vC0 = str2double(get(handles.editV0, 'String')); 
iL0 = str2double(get(handles.editI0, 'String')); 

% 符号计算设置
syms t s y(t);
Dy = diff(y);
ode = L*C*diff(y,t,2) + R*C*diff(y,t) + y == 0; % 基础方程

% 根据响应类型调整方程和初始条件
switch response_type
    case 'impulse'
        ode = L*C*diff(y,t,2) + R*C*diff(y,t) + y == dirac(t)/sqrt(L*C)
        conds = [y(0)==0, Dy(0)==0];
        
    case 'zero_input'
        ode = L*C*diff(y,t,2) + R*C*diff(y,t) + y == 0;
        conds = [y(0) == vC0, Dy(0) == iL0/C];
        
    case 'zero_state'
            excitation = get_excitation(handles);
        ode = L*C*diff(y,t,2) + R*C*diff(y,t) + y == excitation;
        conds = [y(0)==0, Dy(0)==0];
            
    case 'full'
        excitation = get_excitation(handles);
        ode = L*C*diff(y,t,2) + R*C*diff(y,t) + y == excitation;
        conds = [y(0)==vC0, Dy(0)==iL0/C];
end

% 求解微分方程
try
    sol = dsolve(ode, conds);
    t = 0:0.01:50;
    y = double(subs(sol, t));
catch
    errordlg('方程求解失败，请检查参数合理性！');
    t = [];
    y = [];
end

% ====================== 回调函数 =========================
% --- 冲激响应
function push_impulse_Callback(hObject, ~, handles)
[t, h] = calculate_response(handles, 'impulse');
axes(handles.axes1);
plot(t, h, 'LineWidth', 1.5);
title('冲激响应'); grid on;

% --- 零输入响应
function push_zi_Callback(hObject, ~, handles)
[t, y_zi] = calculate_response(handles, 'zero_input');
axes(handles.axes2);
plot(t, y_zi, 'LineWidth', 1.5);
title('零输入响应'); grid on;

% --- 零状态响应
function push_zs_Callback(hObject, ~, handles)
[t, y_zs] = calculate_response(handles, 'zero_state');
axes(handles.axes3);
plot(t, y_zs, 'LineWidth', 1.5);
title('零状态响应'); grid on;

% --- 全响应
function push_full_Callback(hObject, ~, handles)
[t, y_full] = calculate_response(handles, 'full');
axes(handles.axes4);
plot(t, y_full, 'LineWidth', 1.5);
title('全响应'); grid on;

% --- 激励信号生成函数
    function f = get_excitation(handles)
    syms t;
    % 获取原始激励信号x(t)
    switch get(handles.popupmenu_excitation, 'Value')
        case 1 % 阶跃
            x = heaviside(t);
        case 2 % 正弦
            x = sin(t);
        case 3 % 脉冲
            x = heaviside(t) - heaviside(t-5);
        case 4 % 指数
            x = exp(-3*t);
        case 5 % 冲激
            x = dirac(t);
        case 6 % 余弦
            x = cos(t);
    end
    
    % 获取用户输入的系数
    try
        coeff_str = get(handles.editCoeffs, 'String');
        [a0, a1, a2] = parse_coefficients(coeff_str);
    catch ME
        errordlg(['系数输入错误: ' ME.message]);
        f = sym(0);
        return;
    end
    
    % 将系数转换为符号类型
    a0_sym = sym(a0);
    a1_sym = sym(a1);
    a2_sym = sym(a2);
    
    % 生成等效激励函数
    dx = diff(x, t);
    d2x = diff(x, t, 2);
    f = a0_sym*x + a1_sym*dx + a2_sym*d2x;
    
    % 对冲激导数进行数值归一化（抑制高阶导数项）
    if has(f, 'dirac')
        f = simplify(f);
        % 移除冲激的一阶和二阶导数项
        f = subs(f, diff(dirac(t), t), 0); % 一阶导数
        f = subs(f, diff(dirac(t), t, 2), 0); % 二阶导数
    end
    
    % 添加因果性约束
    f = f .* heaviside(t);

% --- 返回按钮
function push_back_Callback(~, ~, ~)
close(gcf);
mystart;

% ================== 物理量转换函数 ====================
function voltage = get_voltage(handles, y)
% 根据选择的响应类型转换物理量
R = str2double(get(handles.editR, 'String'));
switch get(handles.popup_response, 'Value')
    case 1 % 电容电压
        voltage = y;
    case 2 % 电感电压
        voltage = -R*y; % 根据KVL计算
    case 3 % 电阻电压
        voltage = R*y;
    case 4 % 回路电流
        voltage = y; % 电流量需特殊处理
end



function editCoeffs_Callback(hObject, eventdata, handles)
% hObject    handle to editCoeffs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editCoeffs as text
%        str2double(get(hObject,'String')) returns contents of editCoeffs as a double


% --- Executes during object creation, after setting all properties.
function editCoeffs_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editCoeffs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function [a0, a1, a2] = parse_coefficients(input_str)
    % 强制要求输入三个系数，允许逗号或空格分隔
    coeffs = strsplit(strtrim(input_str), {' ', ','}, 'CollapseDelimiters', true);
    
    % 检查输入数量
    if numel(coeffs) ~= 3
        error('必须输入三个系数，例如："1, 0, 0" 或 "1 0.5 -2"');
    end
    
    % 转换为数值并验证
    a0 = str2double(coeffs{1});
    a1 = str2double(coeffs{2});
    a2 = str2double(coeffs{3});
    
    if any(isnan([a0, a1, a2]))
        error('输入包含非数字字符');
    end
    
    % 检查系数是否全为0
    if (a0 == 0) && (a1 == 0) && (a2 == 0)
        error('系数不能全为0');
    end