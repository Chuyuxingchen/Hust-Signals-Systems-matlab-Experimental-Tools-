% 方波合成参数
f = 50;          % 基波频率(Hz)
A = 2;           % 幅值
t = 0:0.0001:0.04; % 时间范围(覆盖2个周期)
w = 2*pi*f;      % 角频率

% 傅里叶级数展开(前5项奇次谐波)
square_wave = (4*A/pi) * (...
    sin(w*t)/1 + ...      % 基波
    sin(3*w*t)/3 + ...    % 3次谐波
    sin(5*w*t)/5 + ...    % 5次谐波 
    sin(7*w*t)/7 + ...    % 7次谐波
    sin(9*w*t)/9);        % 9次谐波

% 生成理想方波对比
ideal_square = A*square(w*t); % 相位调整对齐
ideal_square(ideal_square > 0) = A;
ideal_square(ideal_square < 0) = -A;

% 可视化结果
figure
plot(t*1000, square_wave, 'LineWidth', 2) % 时间转换为毫秒
hold on
plot(t*1000, ideal_square, '--', 'LineWidth', 1.5)
title('方波合成（前5次谐波）')
xlabel('时间 (ms)')
ylabel('幅值')
legend('谐波合成', '理想方波')
grid on
xlim([0 40]) % 显示2个周期
set(gca, 'FontSize', 12)