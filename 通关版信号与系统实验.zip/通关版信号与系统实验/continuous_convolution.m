function varargout = continuous_convolution(varargin)

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @continuous_convolution_OpeningFcn, ...
                   'gui_OutputFcn',  @continuous_convolution_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

function continuous_convolution_OpeningFcn(hObject, eventdata, handles, varargin)

handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes continuous_convolution wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = continuous_convolution_OutputFcn(hObject, eventdata, handles) 

varargout{1} = handles.output;


% 函数x的类型选择框
function popupmenu1_Callback(hObject, eventdata, handles)

function popupmenu1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%输入函数x中参数a的值
function edit1_Callback(hObject, eventdata, handles)
global a10;%定义全局变量a1
a10 = str2double(get(hObject,'String'));%读取edit1中的字符串并把字符转换成数值，并将该数值赋值给a10
guidata(hObject, handles);%存储变量data的值作为figure的数据，更新gui

function edit1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% 输入函数x中参数b的值
function edit2_Callback(hObject, eventdata, handles)

global b10;
b10 = str2double(get(hObject,'String'));%读取edit2中的字符串并把字符转换成数值，并将该数值赋值给b1
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%函数y的类型选择框
function popupmenu2_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit3_Callback(hObject, eventdata, handles)
global a20;
a20 = str2double(get(hObject,'String'));%读取edit3中的字符串并把字符转换成数值，并将该数值赋值给a2
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit4_Callback(hObject, eventdata, handles)
global b20;
b20 = str2double(get(hObject,'String'));%读取edit4中的字符串并把字符转换成数值，并将该数值赋值给b2
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% 菜单
function menu_Callback(hObject, eventdata, handles)
% hObject    handle to menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% 菜单绘制函数x
function plotx_Callback(hObject, eventdata, handles)
syms t;%定义符号变量t,t可以进行符号操作
global x;
global a1;
global b1;
global axs1;
global choose1;%函数x的种类
global axs11;
global x1;
global a10;%输入的a的值
global b10;%输入的b的值
a1=a10;
b1=b10;
%判断边界条件
if isempty(a1)  %a1为一个数（判断a1的输入值是否为空）
    msgbox('input a first','warn','warn'); %如果输入a1的值为空，则弹出警告
    return
else
    if length(a1)>1
        msgbox('a should be a single number','warn','warn');%输入a1的值必须为个位数
        return
    else
        a1=a1(1);
    end
end
if isempty(b1)%b1不为空
    msgbox('input b first','warn','warn');
    return
else
    if length(b1)>1
        msgbox('b should be a single number','warn','warn');
        return
    else
        b1=b1(1);
    end
end
choose1 = get(handles.popupmenu1,'value');%choose1为函数x表达式
switch choose1
    case 1%门函数
        if b1<=0
            msgbox('b should be positive','warn','warn');%参数b必须为正数
            return
        end
        x=heaviside(t-(a1-b1/2))-heaviside(t-(a1+b1/2));%利用阶跃函数heaviside()构建门函数
        axes(handles.axes1);%画图像在坐标轴1
        axs1=[(a1-b1/2)-3 (a1+b1/2)+3];%设置x坐标范围为(a1-b1/2)-3到(a1+b1/2)+3
        axs11=a1-b1/2-3:0.1:a1+b1/2+3;%设置步进值为0.1
        x1=double(subs(x,t,axs11));%将x中的t替换为axs11,并将数组转换为double型赋值给x1
        x1(min(find(isnan(x1))))=1;%将阶跃函数中的上限转为1
        x1(max(find(isnan(x1))))=0;%将阶跃函数中的下限转化为0
        fplot(x,axs1);%画出门函数用fplot定义变量x范围
        axis([(a1-b1/2-3),(a1+b1/2+3),0,1.1]);%设置坐标轴xmin xmax ymin ymax不顶天立地
        grid on;%画网格线
    case 2%三角函数
        if b1<=0
            msgbox('b should be positive','warn','warn');
            return
        end
        x=(heaviside(t-(a1-b1/2))-heaviside(t-a1))*(t-(a1-b1/2))*2/b1+(heaviside(t-a1)-heaviside(t-(a1+b1/2)))*(-t+(a1+b1/2))*2/b1;%利用阶跃函数构建三角函数
        axs1=[(a1-b1/2)-3 (a1+b1/2)+3];
        axes(handles.axes1);%将上面的坐标轴作为当前坐标轴
        fplot(x,axs1);%画出中心为a,宽度为b的三角函数
        axis([(a1-b1/2)-3 (a1+b1/2)+3 0 1.1]);
        grid on;
    case 3%阶跃函数
        if a1==0
            msgbox('a can not be zero','warn','warn');
            return
        end
        x=heaviside(a1*t-b1);%阶跃函数表达式
        axs1=[b1/a1-3 b1/a1+3];
        axes(handles.axes1);
        fplot(x,axs1);
        axis([b1/a1-3,b1/a1+3,0,1.1]);%(at-b)=0作为中心坐标
        grid on;
       

    case 4%冲激函数
        if a1==0
            msgbox('a can not be zero','warn','warn');
            return
        end
        x=dirac(a1*t-b1);%冲激函数表达式
        axs1=[b1/a1-3 b1/a1+3];
        axs11=(b1/a1-3):0.01:(b1/a1+3);
        axes(handles.axes1);
        stairs(axs11,x1);%绘制阶梯状图
        axis([(b1/a1-3) (b1/a1+3) 0 1.1]);
        x1=subs(x,t,axs11);%将x中的t替换为axs11
        x1(find(x1==inf))=1;%将冲激函数等于inf时的值赋为1
    case 5 %单边指数函数
        if a1==0
            msgbox('a can not be zero，due to some reasons that exist on sources codes','warn','warn');
            return
        end
        x=a1*exp(-abs(b1)*t)*heaviside(t);%单边指数函数表达式
        axs1=[-3 3];%横坐标范围
		axs11=-3:0.01:3;
		axes(handles.axes1);
		x1=subs(x,t,axs11);
		stairs(axs11,x1);
		axis([-3 3 -0.5+a1*(a1<0) a1*(a1>0)+0.5]);%以-0.5+a1作为y下限(a<0),0.5作为上限；0.5+a1作为y的上限（a>0)，-0.5作为下限
		grid on ;
    case 6 %单边正弦函数
        if a1==0
            msgbox('a can not be zero，due to some reasons that exsit on sources codes','warn','warn');
            %由于代码中许多部分带有b1/a1，为了避免程序大面积改动，舍弃常数函数
            return
        end
        x=sin(a1*t+b1)*heaviside(t);
        axs1=[-pi/a1  3*pi/a1];
		axs11=(-pi/abs(a1)):0.01:(3*pi/abs(a1));
		axes(handles.axes1);
		x1=subs(x,t,axs11);
		stairs(axs11,x1);
		axis([-pi/abs(a1)  3*pi/abs(a1)  -1.2  1.2]);
		grid on ;
    case 7 %2u(t)-u(t-2)
        x = 2*heaviside(a1*t + b1) - heaviside(t - 2);
        t1 = -b1/a1;    % 由 a1*t + b1 = 0 得到
        t2 = 2;         % 由 t - 2 = 0 得到
        axs1 = [min(t1, t2)-3, max(t1, t2)+3];
        axes(handles.axes1);
        fplot(x, axs1);
        axis([min(t1, t2)-3, max(t1, t2)+3, -0.1, 2.2]); 
        grid on;
    case 8 %u(t)-u(t-2)
        x = heaviside(a1*t + b1) - heaviside(t - 2);
        t1 = -b1/a1;    % 由 a1*t + b1 = 0 得到
        t2 = 2;         % 由 t - 2 = 0 得到
        axs1 = [min(t1, t2)-3, max(t1, t2)+3];
        axes(handles.axes1);
        fplot(x, axs1);
        axis([min(t1, t2)-3, max(t1, t2)+3, -0.1, 2.2]); 
        grid on;
end  


% 菜单绘制函数y
function ploty_Callback(hObject, eventdata, handles)
% hObject    handle to ploty (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
syms t;
global y;
global a2;
global b2;
global choose2;
global axs2;
global a20;
global b20;
a2=a20;%将输入的a20的值赋值给a2
b2=b20;%将输入的b20的值赋值给b2
if isempty(a2)
    msgbox('input a first','warn','warn');
    return
else
    if length(a2)>1
        msgbox('a should be a single number','warn','warn');
        return
    else
        a2=a2(1);
    end
end
if isempty(b2)
    msgbox('input b first','warn','warn');
    return
else
    if length(b2)>1
        msgbox('b should be a single number','warn','warn');
        return
    else
        b2=b2(1);
    end
end
choose2 = get(handles.popupmenu2,'value');%选择y函数的类型
switch choose2
    case 1
        if b2<=0
            msgbox('b should be positive','warn','warn');
            return
        end
        y=heaviside(t-(a2-b2/2))-heaviside(t-(a2+b2/2));
        axes(handles.axes2);
        axs2=[(a2-b2/2)-3 (a2+b2/2)+3];
        fplot(y,axs2,'r');%绘制y的图像并用红线
        axis([(a2-b2/2-3),(a2+b2/2+3),0,1.1]);
        grid on;
    case 2
        if b2<=0
            msgbox('b should be positive','warn','warn');
            return
        end
        y=(heaviside(t-(a2-b2/2))-heaviside(t-a2))*(t-(a2-b2/2))*2/b2+(heaviside(t-a2)-heaviside(t-(a2+b2/2)))*(-t+(a2+b2/2))*2/b2;
        axes(handles.axes2);
        axs2=[(a2-b2/2)-3 (a2+b2/2)+3];
        fplot(y,axs2,'r');%绘制y的图像并用红线
        axis([a2-b2/2-3 a2+b2/2+3 0 1]);
        grid on;
    case 3
        if a2==0
            msgbox('a can not be zero','warn','warn');
            return
        end
        y=heaviside(a2*t-b2);
        axs2=[b2/a2-3 b2/a2+3];
        axes(handles.axes2);
        fplot(y,axs2,'r');%绘制y的图像并用红线
        axis([b2/a2-3,b2/a2+3,0,1.1]);
        grid on;
    case 4
        if a2==0
            msgbox('a can not be zero','warn','warn');
            return
        end
        y=dirac(a2*t-b2);
        axs2=(b2/a2-3):0.01:(b2/a2+3);
        axes(handles.axes2);
        stairs(axs2,y1,'r');%利用阶梯函数绘制y的图像并用红线
        axis([(b2/a2-3) (b2/a2+3) 0 1.1]);
        y1=subs(y,t,axs2);
        y1(find(y1==inf))=1;%将inf值转化为1
        grid on;
    case 5 
        if a2==0
            msgbox('a can not be zero，due to some reasons that exsit on sources codes','warn','warn');
            return
        end
        y=a2*exp(-abs(b2)*t)*heaviside(t);
		axs22=-3:0.01:3;
		axes(handles.axes2);
		y1=subs(y,t,axs22);
		stairs(axs22,y1,'r');
		axis([-3 3 -0.5+a2*(a2<0) a2*(a2>0)+0.5]);
		grid on ;
    case 6 %由于代码中许多部分带有b2/a2，为了避免程序大面积改动，舍弃常数函数
        if a2==0
            msgbox('a can not be zero，due to some reasons that exsit on sources codes','warn','warn');
            return
        end
        y=sin(a2*t+b2)*heaviside(t);
		axs22=-pi/abs(a2):0.01:3*pi/abs(a2);
		axes(handles.axes2);
		y1=subs(y,t,axs22);
		stairs(axs22,y1,'r');
		axis([-pi/abs(a2) 3*pi/abs(a2) -1.2 1.2]);
		grid on ;
        case 7 %2u(t)-u(t-2)
        x = 2*heaviside(a1*t + b1) - heaviside(t - 2);
        t1 = -b1/a1;    % 由 a1*t + b1 = 0 得到
        t2 = 2;         % 由 t - 2 = 0 得到
        axs1 = [min(t1, t2)-3, max(t1, t2)+3];
        axes(handles.axes1);
        fplot(x, axs1);
        axis([min(t1, t2)-3, max(t1, t2)+3, -0.1, 2.2]); 
        grid on;
        
        case 8 %u(t)-u(t-2)
        x = 2*heaviside(a1*t + b1) - heaviside(t - 2);
        t1 = -b1/a1;    % 由 a1*t + b1 = 0 得到
        t2 = 2;         % 由 t - 2 = 0 得到
        axs1 = [min(t1, t2)-3, max(t1, t2)+3];
        axes(handles.axes1);
        fplot(x, axs1);
        axis([min(t1, t2)-3, max(t1, t2)+3, -0.1, 2.2]); 
        grid on;
end

% 计算卷积
function cov_Callback(hObject, eventdata, handles)
% hObject    handle to cov (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a1;
global b1;
global a2;
global b2;
global x;
global y;
global choose2;
global choose1;
global axs1;
global axs2;  
global axs11;
global x1;
syms t tao;%定义tao

if isempty(x)
    msgbox('select x first','warn','warn');
    return
end

if isempty(y)
    msgbox('select y first','warn','warn');
    return
end

axes(handles.axes3);%绘制计算过程的图像在坐标轴3
cla reset;
axes(handles.axes4);%绘制计算结果的图像在坐标轴4
cla reset;

axs3=axs1;
switch choose2 %choose2为函数y类型
    case 1   %函数y为门函数
        axs3=[min(axs1) max(axs1)+b2-2];
        axs32=min(axs3):0.05:max(axs3)+0.05;
        x1=subs(x,t,axs32);
        switch choose1 
            case 1%函数x为门函数
                x1(min(find(isnan(x1))))=0;
                x1(max(find(isnan(x1))))=1;
                if b1>b2
                    axs444=[min(axs3)+(a2-b2/2),max(axs3)+(a2-b2/2),0,b2+0.4];
                else
                    axs444=[min(axs3)+(a2-b2/2),max(axs3)+(a2-b2/2),0,b1+0.4];
                end
            case 2%函数x为三角函数
                axs32=min(axs3):0.01:max(axs3)+0.05;%卷积的时候用
                x1=subs(x,t,axs32);
                if b1>b2
                    axs444=[min(axs3)+(a2-b2/2),max(axs3)+(a2-b2/2),0,b2];
                else
                    axs444=[min(axs3)+(a2-b2/2),max(axs3)+(a2-b2/2),0,b1/2+0.4];
                end
            case 3%函数x为阶跃函数
                if a1>=0
                    x1(isnan(x1))=1;
                    if (isempty(find(isnan(x1))))==1
                        k=find(x1==0);
                        x1(k(end))=1;%当函数中不存在nan值时将取值为0的最后一个点赋值为1
                    end
                else
                    x1(isnan(x1))=0;
                end
                axs444=[min(axs3)+(a2-b2/2),max(axs3)+(a2-b2/2),0,b2+0.4];
            case 4%函数x为冲激函数
                axs32=min(axs3):0.01:max(axs3)+0.05;
                x1=subs(x,t,axs32);%将x中的t用axs32替换
                x1(find(x1==inf))=1;
                axs444=[min(axs3)+(a2-b2/2),max(axs3)+(a2-b2/2),0,1.1];
                xy_tao=subs(x,t,tao)*subs(y,t,t-tao);%将x中的t用tao替换将y中的t用t-tao替换
                xy=simplify(simplify(int(xy_tao,tao,-100,100)));%卷积过程
            case 5 
                 axs32=min(axs3):0.01:max(axs3)+0.05;
                 x1=subs(x,t,axs32);
                 axs444=[min(axs3)+(a2-b2/2),max(axs3)+(a2-b2/2),(a1<0)*a1*b2+0,0+a1*b2*(a1>0)];
            case 6 
                 axs32=min(axs3):0.01:max(axs3)+0.05;
                 x1=subs(x,t,axs32);
                 axs444=[min(axs3)+(a2-b2/2),max(axs3)+(a2-b2/2),-b2,b2];
        end
        
        axs4=[(min(axs3)+(a2-b2/2))-0.05 (min(axs3)+(a2-b2/2))];
        y2=heaviside(t-(min(axs3)-b2))-heaviside(t-(min(axs3)));%门函数平移
        
        
        for i=min(axs3):0.05:max(axs3)+0.05%步长的确定
            axes(handles.axes3);%画图在坐标轴3
            if choose1==4  
                stairs(axs32,x1,'b');%x函数为冲激函数时用stairs画图
            else
                fplot(x,axs3);%x函数不为冲激函数时用fplot画图
            end
            hold on;
            y22=subs(y2,t,axs32);%将y2中的t用axs32替换
            y22(find(isnan(y22)))=y22(find(isnan(y22))+1);%迭代
            fplot(y2,axs3,'r');%在坐标轴上用红线画y2的图像
            grid on;
            y2=heaviside(t-(i-b2))-heaviside(t-i);%图像区间长度为b2
            hold off;
            if (choose1==4)
                axis tight;
                xlim([min(axs3),max(axs3)]);
            else
                axis([min(axs3),max(axs3),0,1.1]);
            end
            
            if (choose1==4)%x函数为冲激函数
                axes(handles.axes4);%绘制图像在坐标轴4
                fplot(xy,axs4);%绘制卷积结果
                grid on;
                axs4(2)=axs4(2)+0.05;%步长为0.05
                axis(axs444);
                pause(0.001);%等待用户响应
            else
                axes(handles.axes4);
                xy_tao=subs(x,t,tao)*subs(y,t,i+(a2-b2/2)-tao);%将x中的t用tao替换，将y中的t用i+(a2-b2/2)-tao替换
                xy=simplify(simplify(int(xy_tao,tao,-100,100)));%卷积过程
                axs44=(min(axs3)+(a2-b2/2)):0.05:(i+(a2-b2/2));
                k=round((i-min(axs3))/0.05+1);%寻找开始点附近的整数
                xy1(k)=double(xy);%将xy转换为duble类型
                plot(axs44,xy1);
                grid on;
                axis(axs444);
                pause(0.001);
            end
        end
        
    case 2  %函数y为三角函数
        axs3=[min(axs1) max(axs1)+b2-2];
        axs32=min(axs3):0.05:max(axs3)+0.05;
        x1=subs(x,t,axs32);
        switch choose1
            case 1
                x1(min(find(isnan(x1))))=1;
                x1(max(find(isnan(x1))))=0;
                if b1>b2
                    axs444=[min(axs3)+(a2-b2/2),max(axs3)+(a2-b2/2),0,b2/2+0.4];
                else
                    axs444=[min(axs3)+(a2-b2/2),max(axs3)+(a2-b2/2),0,b1];
                end
            case 2
                axs32=min(axs3):0.01:max(axs3)+0.05;
                x1=subs(x,t,axs32);
                if b1>b2
                    axs444=[min(axs3)+(a2-b2/2),max(axs3)+(a2-b2/2),0,b2/2];
                else
                    axs444=[min(axs3)+(a2-b2/2),max(axs3)+(a2-b2/2),0,b1/2];
                end
            case 3
                if a1>=0
                    x1(isnan(x1))=1;
                    if (isempty(find(isnan(x1))))==1
                        k=find(x1==0);
                        x1(k(end))=1;
                    end
                else
                    x1(isnan(x1))=0;
                end
                axs444=[min(axs3)+(a2-b2/2),max(axs3)+(a2-b2/2),0,b2/2+0.4];
            case 4 
                axs32=min(axs3):0.01:max(axs3)+0.05;
                x1=subs(x,t,axs32);
                x1(find(x1==inf))=2;
                axs444=[min(axs3)+(a2-b2/2),max(axs3)+(a2-b2/2),0,1.1];
                xy_tao=subs(x,t,tao)*subs(y,t,t-tao);
                xy=simplify(simplify(int(xy_tao,tao,-100,100)));
            case 5
                axs32=min(axs3):0.01:max(axs3)+0.05;
                x1=subs(x,t,axs32);
                axs444=[min(axs3)+(a2-b2/2),max(axs3)+(a2-b2/2),(a1<0)*a1*b2/2+0,0+a1*b2/2*(a1>0)];
            case 6 
                axs32=min(axs3):0.01:max(axs3)+0.05;
                x1=subs(x,t,axs32);
                axs444=[min(axs3)+(a2-b2/2),max(axs3)+(a2-b2/2),-b2/2,b2/2];
        end
        
        axs4=[(min(axs3)+(a2-b2/2))-0.05 (min(axs3)+(a2-b2/2))];
        
        for i=min(axs3):0.05:max(axs3)+0.05
            axes(handles.axes3);
            if choose1==4
                stairs(axs32,x1,'b');
            else
                fplot(x,axs3);
            end
            grid on;
            hold on;
            axs33=(i-b2):0.05:i;
            y22=zeros(length(axs33));%创建与axs33维度相同的全零矩阵
            for k=1:length(axs33)
                if (axs33(k)>=(i-b2)&&axs33(k)<=(i-b2/2))%(i-b2)<axs33(k)<(i-b2/2)
                    y22(k)=(axs33(k)-(i-b2))*2/b2;
                else
                    y22(k)=(i-axs33(k))*2/b2;
                end
            end
            plot(axs33,y22,'r');
            grid on;
            hold off;
            axis([min(axs3),max(axs3),0.02,1.1]);
            
            if (choose1==4)%函数x为冲激函数
                axes(handles.axes4);
                fplot(xy,axs4);
                grid on;
                axs4(2)=axs4(2)+0.05;
                axis(axs444);
                pause(0.003);
            else
                axes(handles.axes4);
                xy_tao=subs(x,t,tao)*subs(y,t,i+(a2-b2/2)-tao);
                xy=simplify(simplify(int(xy_tao,tao,-100,100)));
                axs44=(min(axs3)+(a2-b2/2)):0.05:i+(a2-b2/2);
                k=round((i-min(axs3))/0.05+1);
                xy1(k)=double(xy);
                plot(axs44,xy1);
                grid on;
                axis(axs444);
                pause(0.001);
            end
        end
        
    case 3  %函数y为阶跃函数
        axs3=[min(axs1) max(axs1)+b2-2];
        axs32=min(axs3):0.05:max(axs3)+0.05;
        x1=subs(x,t,axs32);
        
        switch choose1
            case 1
                x1(min(find(isnan(x1))))=1;
                x1(max(find(isnan(x1))))=0;
                axs444=[min(axs3)+(b2/a2),max(axs3)+(b2/a2),0,b1+0.4];
                
            case 2
                axs32=min(axs3):0.01:max(axs3)+0.05;
                x1=subs(x,t,axs32);
                axs444=[min(axs3)+(b2/a2),max(axs3)+(b2/a2),0,b1/2+0.4];
            case 3
                if a1>=0
                    x1(isnan(x1))=1;
                else
                    x1(isnan(x1))=0;
                end
                axs444=[min(axs3)+(b2/a2),max(axs3)+(b2/a2),-0.05,3.05];
            case 4
                axs32=min(axs3):0.01:max(axs3)+0.05;
                x1=subs(x,t,axs32);
                x1(find(x1==inf))=2;
                axs444=[min(axs3)+(b2/a2),max(axs3)+(b2/a2),0,1.1];
            case 5
                axs32=min(axs3):0.01:max(axs3)+0.05;
                x1=subs(x,t,axs32);
                axs444=[min(axs3)+(b2/a2),max(axs3)+(b2/a2),(a1<0)*a1+0,0+a1*(a1>0)];
            case 6 
                axs32=min(axs3):0.01:max(axs3)+0.05;
                x1=subs(x,t,axs32);
                axs444=[min(axs3)+(b2/a2),max(axs3)+(b2/a2),-2/abs(a1),2/abs(a1)];
        end
        
        y2=heaviside(-(a2/abs(a2))*t+(a2/abs(a2))*min(axs3));
        if (choose1==3)||(choose1==4)
            axs4=[b1/a1+b2/a2-3.05 b1/a1+b2/a2-3];
        else
            axs4=[min(axs3)+(b2/a2),min(axs3)+(b2/a2)+0.05];
        end
        %axs4=[b1/a1+b2/a2-3.05 b1/a1+b2/a2-3];
        
        if (choose1==1)||(choose1==2)%函数x为门函数或三角函数
            
            for i=min(axs3):0.05:max(axs3)+0.1
                axes(handles.axes3);
                fplot(x,axs3);
                hold on;
                y22=subs(y2,t,axs32);
                fplot(y2,axs3,'r');
                grid on;
                y2=heaviside(-(a2/abs(a2))*t+(a2/abs(a2))*i);%y2的取值范围
                hold off;
                axis([min(axs3),max(axs3),-1.1,1.1]);
                axes(handles.axes4);
                xy_tao=subs(x,t,tao)*subs(y,t,i+b2/a2-tao);
                xy=simplify(simplify(int(xy_tao,tao,-inf,inf)));
                axs44=(min(axs3)+b2/a2):0.05:i+b2/a2;
                k=round((i+b2/a2-(min(axs3)+b2/a2))/0.05+1);
                xy1(k)=double(xy);
                plot(axs44,xy1);
                grid on;
                axis(axs444);
                pause(0.001);
            end
            
        else %函数x为其他函数
            if ((a1/abs(a1))~=(a2/abs(a2)))&&(choose1==3)
                msgbox('x、y都为阶跃函数时,两个a参数必须同号','warn','warn');
                return
            end
            xy_tao=subs(x,t,tao)*subs(y,t,t-tao);
            xy=simplify(simplify(int(xy_tao,tao,-100,100)));
            for i=min(axs3):0.05:max(axs3)+0.1
                axes(handles.axes3);
                if choose1==4
                    axs11=(b1/a1-3):0.01:(b1/a1+3);
                    x1=subs(x,t,axs11);
                    x1(find(x1==inf))=2;
                    stairs(axs11,x1,'b');
                else
                    fplot(x,axs3);
                end
                hold on;
                y22=subs(y2,t,axs32);
                y22(isnan(y22))=1;
                fplot(y2,axs3,'r');
                grid on;
                y2=heaviside(-(a2/abs(a2))*t+(a2/abs(a2))*i);
                hold off;
                axis(axs444);
                %axis([b1/a1-3,b1/a1+3,-1.1,1.1]);
                axes(handles.axes4);
                fplot(xy,axs4);
                grid on;
                axs4(2)=axs4(2)+0.05;
                axis(axs444);
                pause(0.001);
            end
        end
        
        
    case 4  %函数y为冲激函数
        axs3=[min(axs1) max(axs1)+b2-2];
        axs4=[min(axs1)+b2/a2-0.05 min(axs1)+b2/a2];
        if choose1==4   %冲激卷积，另外处理
            axs43=[b1/a1+b2/a2-0.01 b1/a1+b2/a2  b1/a1+b2/a2+0.01];
            xy3=[0 1 0];
        else
            xy_tao=subs(x,t,tao)*subs(y,t,t-tao);
            xy=simplify(simplify(int(xy_tao,tao,-inf,inf)));
        end
        for i=min(axs3):0.05:max(axs3)+0.05
            axes(handles.axes3);
            if choose1==4 %函数x为阶跃函数
                stairs(axs11,x1(1:1:length(axs11)));
            else
                fplot(x,axs3);
            end
            y2=dirac(t-i);
            axs32=min(axs3):0.005:i;
            hold on;
            y22=subs(y2,t,axs32);
            y22(end)=1;
            stairs(axs32,y22,'r');
            grid on;
            hold off;
            axis([min(axs3),max(axs3),0,2]);
            axes(handles.axes4);
            if choose1==4
                axs42=min(axs3)+b2/a2:0.05:i+b2/a2;
                xy2=zeros(length(axs42));
                plot(axs42,xy2,'b');
                grid on;
                if (i>=(b1/a1))
                    hold on;
                    stairs(axs43,xy3);
                    grid on;
                    hold off;
                end
            elseif choose1==6 %由于未知原因，将单边正弦信号单独处理
                axs44=axs4(1):0.01:axs4(2);
                stairs(axs44,real(subs(xy,t,axs44)));
                grid on;
                axs4(2)=axs4(2)+0.05;
            else
                fplot(xy,axs4);
                grid on;
                axs4(2)=axs4(2)+0.05;
            end
            axis([min(axs3)+b2/a2,max(axs3)+b2/a2,0,3]);
            pause(0.001);            
        end
        
    case 5 %函数y为单边指数函数
        axs3=[min(axs1) max(axs1)];
        axs32=min(axs3):0.05:max(axs3)+0.05;
        x1=subs(x,t,axs32);
        
        switch choose1
            case 1%函数x为门函数
                x1(min(find(x1==0.5)))=1;
                x1(max(find(x1==0.5)))=0;
                axs444=[min(axs3),max(axs3),a2*(a2<0),a2*(a2>=b1+0.4)+(b1+0.4)*(a2<b1+0.4)];
            case 2%函数x为三角函数
                axs32=min(axs3):0.01:max(axs3)+0.05;
                x1=subs(x,t,axs32);
                axs444=[min(axs3),max(axs3),a2*(a2<0),a2*(a2>=b1/2+0.4)+(b1/2+0.4)*(a2<b1/2+0.4)];
            case 3%函数x为阶跃函数
                if a1>=0
                    x1(x1==0.5)=1;
                    if (isempty(find(x1==0.5)))==1
                        k=find(x1==0);
                        x1(k(end))=1;
                    end
                else
                    x1(x1==0.5)=0;
                end
                axs444=[min(axs3),max(axs3),-a2/abs(b2),a2/abs(b2)];
            case 4%函数x为冲激函数
                axs32=min(axs3):0.01:max(axs3)+0.05;
                x1=subs(x,t,axs32);
                x1(find(x1==inf))=2;
                axs444=[min(axs3),max(axs3),-0.1+a2*(a2<0),a2*(a2>0)+0.1];
            case 5%函数x为单边指数函数
                axs32=min(axs3):0.01:max(axs3)+0.05;
                x1=subs(x,t,axs32);
                axs444=[min(axs3),max(axs3),-a2/abs(b2),a2/abs(b2)];
            case 6
                axs32=min(axs3):0.01:max(axs3)+0.05;
                x1=subs(x,t,axs32);
                axs444=[min(axs3),max(axs3),-a2/abs(b2),a2/abs(b2)];
        end
        axs4=[min(axs3)-0.05  min(axs3)];
        xy_tao=subs(x,t,tao)*subs(y,t,t-tao);
        xy=simplify(simplify(int(xy_tao,tao,-100,100)));
        
        
        for i=min(axs3):0.05:max(axs3)+0.05
            
            axes(handles.axes3);
            stairs(axs32,x1);
            hold on;
            y2=a2*exp(-abs(b2)*(i-t))*heaviside(i-t);
            axs333=min(axs3):0.01:max(axs3)+0.01;
            y22=subs(y2,t,axs333);
            stairs(axs333,y22,'r');
            grid on;
            hold off;
            axis([axs444(1:2),-0.1-abs(a2),0.1+abs(a2)]);
            
            axes(handles.axes4);
            fplot(xy,axs4);
            grid on;
            axs4(2)=axs4(2)+0.05;
            
            axis(axs444);
            pause(0.001);
        end
    case 6  %函数y为单边正弦函数
        
        axs3=[min(axs1) max(axs1)];
        axs32=min(axs3):0.05:max(axs3)+0.05;
        x1=subs(x,t,axs32);
        
        switch choose1
            case 1
                x1(min(find(x1==0.5)))=1;
                x1(max(find(x1==0.5)))=0;
                axs444=[min(axs3),max(axs3),-1.5,1.5];
            case 2
                axs32=min(axs3):0.01:max(axs3)+0.05;
                x1=subs(x,t,axs32);
                axs444=[min(axs3),max(axs3),-1.5,b1/2+0.4];
            case 3
                if a1>=0
                    x1(x1==0.5)=1;
                    if (isempty(find(x1==0.5)))==1
                        k=find(x1==0);
                        x1(k(end))=1;
                    end
                else
                    x1(x1==0.5)=0;
                end
                axs444=[min(axs3),max(axs3),-2,2];
            case 4
                axs32=min(axs3):0.01:max(axs3)+0.05;
                x1=subs(x,t,axs32);
                x1(find(x1==inf))=2;
                axs444=[min(axs3),max(axs3),-1.5,1.5];
            case 5
                axs32=min(axs3):0.01:max(axs3)+0.05;
                x1=subs(x,t,axs32);
                axs444=[min(axs3),max(axs3),-abs(a1)/2,abs(a1)/2];
            case 6
                axs32=min(axs3):0.01:max(axs3)+0.05;
                x1=subs(x,t,axs32);
                axs444=[min(axs3),max(axs3),-1.1,1.1];
        end
        axs4=[min(axs3)-0.05  min(axs3)];
        xy_tao=subs(x,t,tao)*subs(y,t,t-tao);
        xy=simplify(simplify(int(xy_tao,tao,-50,50)));
        
        
        for i=min(axs3):0.05:max(axs3)+0.05
            
            axes(handles.axes3);
            stairs(axs32,x1);
            hold on;
            y2=sin(a2*(i-t)+b2)*heaviside(i-t);
            axs333=min(axs3):0.01:max(axs3)+0.01;
            y22=subs(y2,t,axs333);
            stairs(axs333,y22,'r');
            grid on;
            hold off;
            axis([axs444(1:2),-2,2]);
            
            axes(handles.axes4);
            fplot(xy,axs4);
            grid on;
            axs4(2)=axs4(2)+0.05;
            axis(axs444);
            pause(0.001);
        end
end

% 菜单返回
function comeback_Callback(hObject, eventdata, handles)
close gcf;
mystart;


% 帮助
function help_Callback(hObject, eventdata, handles)
str={'1.下拉选择函数x,函数y的类型',...
    '2.在文本框中输入函数x和函数y中的参数a,参数b的值',...
    '3.之后通过控制栏按钮或菜单栏选择绘制函数x,函数y的图形并进行卷积运算',...
    '4.按下返回按钮或者菜单栏返回键可以返回主界面',...
    '5.按下清除按钮或者菜单栏清除键可以清空波形和参数',...
    };
h=msgbox(str,'help');
%set(h,'Resize','on');
%set(h,'Position',[100 100 500 500]);


% --- Executes during object deletion, before destroying properties.
function popupmenu2_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on key press with focus on popupmenu1 and none of its controls.
function popupmenu1_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function axes3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes3


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
ha=axes('units','normalized','pos',[0 0 1 1]);
uistack(ha,'bottom');
ii=imread('侠客.jfif');
image(ii);
colormap gray
set(ha,'handlevisibility','off','visible','off'); 


% 按钮绘制函数x
function pushbutton1_Callback(hObject, eventdata, handles)
plotx_Callback(hObject, eventdata, handles)

%按钮绘制函数y
function pushbutton2_Callback(hObject, eventdata, handles)
ploty_Callback(hObject, eventdata, handles)

%按钮计算卷积
function pushbutton3_Callback(hObject, eventdata, handles)
cov_Callback(hObject, eventdata, handles)


function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% 返回
function pushbutton6_Callback(hObject, eventdata, handles)
comeback_Callback(hObject, eventdata, handles)

% 菜单清除
function clear_Callback(hObject, eventdata, handles)
% hObject    handle to clear (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    delete(allchild(handles.axes1));
    delete(allchild(handles.axes2));
    delete(allchild(handles.axes3));
    delete(allchild(handles.axes4));
    set(handles.edit1,'string','');
    set(handles.edit2,'string','');
    set(handles.edit3,'string','');
    set(handles.edit4,'string','');
    
% 清除按钮
function pushbutton7_Callback(hObject, eventdata, handles)
clear_Callback(hObject, eventdata, handles)
