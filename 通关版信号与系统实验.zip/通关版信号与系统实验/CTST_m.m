function second_order_bode()
    % 创建图形窗口和坐标轴
    fig = figure('Name','二阶系统频响分析','NumberTitle','off');
    ax = axes('Parent', fig);
    
    % 定义m值数组
    m_values = [0.1, 0.3, 0.5, 0.7, 0.9];
    colors = ['r','g','b','c','m']; % 颜色编码
    legend_labels = cell(1,length(m_values));
    
    hold(ax, 'on');
    
    % 遍历所有m值
    for i = 1:length(m_values)
        m = m_values(i);
        
        % 系统函数系数
        num = [1];         % 分子多项式
        den = [1 2*m 1];   % 分母多项式
        
        % 计算频率响应
        [H,w] = freqs(num, den, logspace(-1,1,500));
        
        % 计算幅值（dB）
        mag = 20*log10(abs(H));
        
        % 绘制曲线
        semilogx(ax, w, mag, 'Color', colors(i), 'LineWidth',1.5);
        legend_labels{i} = ['m = ', num2str(m)];
    end
    
    % 图形美化
    hold(ax, 'off');
    grid(ax, 'on');
    title(ax, '二阶系统幅频特性');
    xlabel(ax, 'Frequency (rad/s)');
    ylabel(ax, 'Magnitude (dB)');
    legend(ax, legend_labels, 'Location','best');
    set(ax, 'XMinorGrid','on', 'YMinorGrid','on');
    
    % 设置坐标范围
    xlim(ax, [0.1 10]);
    ylim(ax, [-40 20]);
end