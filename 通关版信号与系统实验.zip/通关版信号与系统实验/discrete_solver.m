function varargout = discrete_solver(varargin)
% DISCRETE_SOLVER MATLAB code for discrete_solver.fig
%      DISCRETE_SOLVER, by itself, creates a new DISCRETE_SOLVER or raises the existing
%      singleton*.
%
%      H = DISCRETE_SOLVER returns the handle to a new DISCRETE_SOLVER or the handle to
%      the existing singleton*.
%
%      DISCRETE_SOLVER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DISCRETE_SOLVER.M with the given input arguments.
%
%      DISCRETE_SOLVER('Property','Value',...) creates a new DISCRETE_SOLVER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before discrete_solver_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to discrete_solver_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help discrete_solver

% Last Modified by GUIDE v2.5 17-May-2025 17:05:45

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @discrete_solver_OpeningFcn, ...
                   'gui_OutputFcn',  @discrete_solver_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before discrete_solver is made visible.
function discrete_solver_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to discrete_solver (see VARARGIN)

% Choose default command line output for discrete_solver
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes discrete_solver wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = discrete_solver_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes during object creation, after setting all properties.
function edit_a_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_a (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function edit_b_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function edit_ics_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_ics (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function edit_K_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_K (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_impulse.
% 单位冲激响应按钮
function pushbutton_impulse_Callback(hObject, eventdata, handles)
    global h_impulse;
    calculate_system(handles);
    axes(handles.axes_impulse);
    stem(h_impulse, 'filled', 'MarkerSize', 3);
    title('单位冲激响应');
    xlabel('样本点 n');
    ylabel('h[n]');
    grid on;
    axis tight;

% 零输入响应按钮
function pushbutton_zeroinput_Callback(hObject, eventdata, handles)
    global h_zeroinput;
    calculate_system(handles);
    axes(handles.axes_zeroinput);
    stem(h_zeroinput, 'filled', 'MarkerSize', 3);
    title('零输入响应');
    xlabel('样本点 n');
    ylabel('y_{zi}[n]');
    grid on;
    axis tight;

% 零状态响应按钮
function pushbutton_zerostate_Callback(hObject, eventdata, handles)
    global h_zerostate;
    calculate_system(handles);
    axes(handles.axes_zerostate);
    stem(h_zerostate, 'filled', 'MarkerSize', 3);
    title('零状态响应');
    xlabel('样本点 n');
    ylabel('y_{zs}[n]');
    grid on;
    axis tight;

% 全响应按钮
function pushbutton_total_Callback(hObject, eventdata, handles)
    global h_total;
    calculate_system(handles);
    axes(handles.axes_total);
    stem(h_total, 'filled', 'MarkerSize', 3);
    title('全响应');
    xlabel('样本点 n');
    ylabel('y_{total}[n]');
    grid on;
    axis tight;

% 文本显示按钮
function pushbutton_text_Callback(hObject, eventdata, handles)
    global h_impulse h_zeroinput h_zerostate h_total;
    calculate_system(handles);
    
    text_content = {
        '=== 单位冲激响应 ===', sprintf('%8.4f ', h_impulse), newline,...
        '=== 零输入响应 ===', sprintf('%8.4f ', h_zeroinput), newline,...
        '=== 零状态响应 ===', sprintf('%8.4f ', h_zerostate), newline,...
        '=== 全响应 ===', sprintf('%8.4f ', h_total)
    };
    
    h_fig = figure('Name','响应数据','NumberTitle','off');
    uicontrol(h_fig, 'Style','edit',...
        'Units','normalized',...
        'Position',[0.05 0.05 0.9 0.9],...
        'Max',10,...
        'String',text_content,...
        'FontName','FixedWidth',...
        'HorizontalAlignment','left');

% 返回按钮
function pushbutton_back_Callback(hObject, eventdata, handles)
    close(gcf);
    mystart;

function edit_a_Callback(hObject, eventdata, handles)
    set(hObject, 'BackgroundColor', [1 1 1]); % 恢复白色背景

function edit_b_Callback(hObject, eventdata, handles)
    set(hObject, 'BackgroundColor', [1 1 1]);

function edit_ics_Callback(hObject, eventdata, handles)
    set(hObject, 'BackgroundColor', [1 1 1]);

function edit_K_Callback(hObject, eventdata, handles)
    set(hObject, 'BackgroundColor', [1 1 1]);

% 全局变量存储计算结果
global h_impulse h_zeroinput h_zerostate h_total;
h_impulse = [];
h_zeroinput = [];
h_zerostate = [];
h_total = [];

% 主计算函数
function calculate_system(handles)
    reset_global_data();
    
    % 输入验证
    [params, errMsg] = validate_inputs(handles);
    if ~isempty(errMsg)
        handle_error(errMsg, handles);
        return;
    end
    
    % 系数对齐
    [a_pad, b_pad] = align_coefficients(params.a, params.b);
    
    % 计算响应
    compute_all_responses(a_pad, b_pad, params.ics, params.K);

% 局部函数定义（必须放在主函数之后）
% -------------------------------------------------------------------------
function reset_global_data()
    global h_impulse h_zeroinput h_zerostate h_total;
    h_impulse = [];
    h_zeroinput = [];
    h_zerostate = [];
    h_total = [];

function [params, errMsg] = validate_inputs(handles)
    params = struct();
    errMsg = '';
    
    try
        params.a = str2num(get(handles.edit_a, 'String'));
        params.b = str2num(get(handles.edit_b, 'String'));
        params.ics = str2num(get(handles.edit_ics, 'String'));
        params.K = str2double(get(handles.edit_K, 'String'));
    catch
        errMsg = '输入解析失败：请检查格式';
        return;
    end
    
    if isempty(params.a) || isempty(params.b)
        errMsg = '系数a/b不能为空';
        return;
    end
    
    required_ics_length = max(length(params.a), length(params.b)) - 1;
    if length(params.ics) ~= required_ics_length
        errMsg = sprintf('初始状态需要%d个值', required_ics_length);
        return;
    end
    
    if params.K <=0 || mod(params.K,1)~=0
        errMsg = 'K必须是正整数';
        return;
    end

function handle_error(errMsg, handles)
    set(handles.edit_a, 'BackgroundColor', [1 1 1]);
    set(handles.edit_b, 'BackgroundColor', [1 1 1]);
    set(handles.edit_ics, 'BackgroundColor', [1 1 1]);
    set(handles.edit_K, 'BackgroundColor', [1 1 1]);
    errordlg(errMsg, '输入错误');

function [a_pad, b_pad] = align_coefficients(a, b)
    max_len = max(length(a), length(b));
    a_pad = [a zeros(1, max_len-length(a))];
    b_pad = [b zeros(1, max_len-length(b))];

function compute_all_responses(a, b, ics, K)
    global h_impulse h_zeroinput h_zerostate h_total;
    
    % 冲激响应
    [h_impulse, ~] = impz(b, a, K);
    
    % 零输入响应
    zi = filtic(b, a, ics);
    h_zeroinput = filter([0], a, zeros(1,K), zi);
    
    % 零状态响应
    delta = [1 zeros(1,K-1)];
    h_zerostate = filter(b, a, delta);
    
    % 全响应
    h_total = h_zeroinput + h_zerostate';
