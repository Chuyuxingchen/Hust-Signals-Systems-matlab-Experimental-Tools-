%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%------------------------------------------��������---------------------------------------
%    ����һЩ��������ɢ���У���ʹ�����˽���ɢ���еĸ���Ҷ�任��
% ��Ƶ��Ӧ����Ƶ��Ӧ��������źŸ���Ҷ�任����ʶ��ʹ���߿���ʹ�ù�����
% ����ͨ��������ز������ı��źŵ�Ƶ�����ԣ�ֱ���˽⸵��Ҷ�任���������
%ͬʱ�������л����пɱ༭�ı��򣬹�ʹ�����Լ��������С�
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%GUI�����ʼ����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function varargout = DTFT(varargin)
% DTFT MATLAB code for DTFT.fig
%      DTFT, by itself, creates a new DTFT or raises the existing
%      singleton*.
%
%      H = DTFT returns the handle to a new DTFT or the handle to
%      the existing singleton*.
%
%      DTFT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DTFT.M with the given input arguments.
%
%      DTFT('Property','Value',...) creates a new DTFT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before DTFT_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to DTFT_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DTFT

% Last Modified by GUIDE v2.5 22-Dec-2020 16:46:19

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DTFT_OpeningFcn, ...+
                   'gui_OutputFcn',  @DTFT_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before DTFT is made visible.
function DTFT_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to DTFT (see VARARGIN)

% Choose default command line output for DTFT
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes DTFT wait for user response (see UIRESUME)
% uiwait(handles.DT);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%���ӱ���%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ha=axes('units','normalized','pos',[0 0 1 1]);

 uistack(ha,'bottom');

 ii=imread('����.jfif');
 image(ii);

 colormap gray

 set(ha,'handlevisibility','off','visible','off');

% --- Outputs from this function are returned to the command line.
function varargout = DTFT_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%������������%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       pushbutton1           ��Ƶ��Ӧ���λ��ƺ���
%       pushbutton2           ��Ƶ��Ӧ���λ��ƺ���        
%       pushbutton3           ʱ��ԭ�źŲ��λ��ƺ���
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in pushbutton1.��Ƶ
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% a = str2num(get(handles.edita1,'String'));
%  b = str2num(get(handles.editb2,'String'));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%       ����a��ò���a��ֵ
%       ����b��ò���b��ֵ
%       ����e��ò���DTFTmagmin��ֵ
%       ����f��ò���DTFTmagmax��ֵ
%       choose1��ȡ�����˵�ѡ����
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
a = str2num(get(handles.aINPUT,'String'));
 b = str2num(get(handles.bINPUT,'String'));
 choose1 = get(handles.popupmenu1,'value');
 e = str2num(get(handles.DTFTmagmin,'String'));%��Ƶ��Ӧ��Χ
 f = str2num(get(handles.DTFTmagmax,'String'));
if (isempty(e)||isempty(f))
    e=-pi;
    f=pi;
end
switch choose1
    case 1
         if (isempty(a)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
         if (abs(a)>1||abs(a)==1)%�ж�a�Ƿ����С��1������
       errordlg('a must be less than 1','care');
            return;
         end
           guidata(hObject, handles);
           if(a>1)
               errordlg('a must less than 1','warn');
               return;
           end    
            t=e:0.01:f;%ȡ����Ϊ��ɢ����������
            g = 1./(1-a*exp(-1i*t));
           axes(handles.axes2);
           plot(t,abs(g));  
           h=abs(g);%ȡ����ֵ
            axis([e f 0.5*min(h) max(h)*1.2])
           grid on
         
    case 2
         if (isempty(b)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
         guidata(hObject, handles);
         if (fix(b)~=b)%�ж��Ƿ�Ϊ����
             errordlg('b must be integer');
             return;
         end
         w=e:0.01:f;
         x=exp(-1i*w*b);
         axes(handles.axes2);
         plot(w,abs(x));
         axis([e f min(abs(x))-1 max(abs(x))+1]);
         grid on;
         
    case 3
         if (isempty(a)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
           guidata(hObject, handles);
           n=-128:128;
          if(a>=1||a<=0)
               errordlg('a must be positive and less than 1','warn');
               return;
          end 
%            g=subs(m,x,t);
           x=a.^abs(n);
           k=(e*100):(f*100);% ��-128��128�ƽ���ɢʱ�丵��Ҷ�任 
           w=(pi/100)*k;  %ת��Ϊ˫���� ���⻭ͼʱ�������������Ͳ�һ����
           X=x*(exp(-1i*pi/100)).^(n'*k);
           magX=abs(X);
            axes(handles.axes2);
            plot(w,magX);
%             plot(t,abs(g));
            grid on;
            axis([e f -0.5 (1+a)/(1-a)+3]);
         
    case 4
         if (isempty(a)||isempty(b)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
        t=e:0.01:f;
%         x=a*rectpuls(t,2*b);
        x=a*(heaviside(t+b)-heaviside(t-b));%�ý�Ծ�������ź���
        y=(x);
        axes(handles.axes2);
%         plot(t/pi,x);  
        plot((t),y);
        axis([e f -1*a a.*2]);
        grid on;
    case 5
         if (isempty(a)||isempty(b)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
             n=0:128;
             if(b==0||a==0)
               errordlg('a and b must not be 0','warn');
               return;
             end 
           x=a*exp(-b*n);
           k=(e*100):(f*100);%ȡ��
           w=(pi/100)*k;%���Ƶ��
           X=x*(exp(-1i*pi/100)).^(n'*k);%����Ҷ�任
            magX=abs(X);
            axes(handles.axes2);
            plot(w,magX);
            grid on;
            axis([e f -0.1.*max(magX) max(magX).*1.2]);%Ϊ�˸��ù۲�ͼ�񣬽���b������1
    case 6
         if (isempty(b)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
            guidata(hObject, handles);
           if b >= 0
               n=-b:b;
               x=a*((n+b)>=0&(n-b)<0); % n = b ʱֵӦΪ0
           else
               n=b:-b;
               x=-a*((n+b)<0&(n-b)>=0);
           end
%             n=-b:b;
%             x=a*((n+b)>=0&(n-b)<=0);
            k=(e*100):(f*100);
            w=(pi/100)*k;
            X=x*(exp(-1i*pi/100)).^(n'*k);
            magX=abs(X);
            axes(handles.axes2);
            plot(w,magX);
            grid on;
           axis([e f floor(min(magX)-1) max(magX)+2]);
    case 7
         if (isempty(a)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
            guidata(hObject, handles);
            n=0:128;
              if(a>=1||a<=0)
               errordlg('a must be positive and less than 1','warn');
               return;
              end 
            x=(n+1).*a.^n.*(n>=0);
            k=(e*100):(f*100);
            w=(pi/100)*k;
            X=x*(exp(-1i*pi/100)).^(n'*k);
            magX=abs(X);
            axes(handles.axes2);
            plot(w,magX);
             grid on;% ����ֻ��һ�����ڣ���Ƶ�ʷ�ΧΪ-1��1
             axis([e f -1 max(magX).*1.2]);
    
end

% --- Executes on button press in pushbutton2.��Ƶ
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%  a = str2num(get(handles.edita1,'String'));
%  b = str2num(get(handles.editb2,'String'));
a = str2num(get(handles.aINPUT,'String'));
b = str2num(get(handles.bINPUT,'String'));
 choose1 = get(handles.popupmenu1,'value');
 e = str2num(get(handles.DTFTangmin,'String'));%��Ƶ��Χ
 f = str2num(get(handles.DTFTangmax,'String'));
 if (isempty(a)||isempty(e)||isempty(f))
     e=-pi;
     f=pi;
 end
 switch choose1
    case 1
         if (isempty(a)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
        if (abs(a)>1||abs(a)==1)
       errordlg('a must be less than 1','care');
            return;
         end
           guidata(hObject, handles);
%            syms x n;
           if(a>1)
               errordlg('a must less than 1','warn');
               return;
           end    
%            s1=a.^n*exp(-1i*x*n);
%            m=symsum(s1,n,0,inf); %��ͼ��㸵��Ҷ�任(����)  ����ʱ��̫������ȡ
            t=e:0.01:f;
%            g=subs(m,x,t);
            g = 1./(1-a*exp(-1i*t));
           axes(handles.axes3);
           plot(t,angle(g));  
           axis([e f -pi pi]);
           set(gca,'YTick',-pi:pi/2:pi);
           set(gca,'ytickLabel',{'-��','-��/2','0','��/2','��'});
           grid on
         
    case 2
         if (isempty(b)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
         guidata(hObject, handles);
         if (fix(b)~=b)
             errordlg('b must be integer');
             return;
         end
         w=e:0.01:f;
         x=exp(-1i*w*b);%
         axes(handles.axes3);
         plot(w,angle(x));
         axis([e f -pi pi]);
         set(gca,'YTick',-pi:pi/2:pi);
         set(gca,'ytickLabel',{'-��','-��/2','0','��/2','��'});
         grid on;
         
    case 3
         if (isempty(a)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
           guidata(hObject, handles);
           n=-128:128;
          if(a>=1||a<=0)
               errordlg('a must be positive and less than 1','warn');
               return;
          end 
%            syms x n;
%            s1=a.^abs(n)*exp(-1i*x*n);
%            m=symsum(s1,n,-inf,inf); %��ͼ��㸵��Ҷ�任  ����ʱ��̫������ȡ
%            t=e:0.01:f;
%            g=subs(m,x,t);
           x=a.^abs(n);
           k=(e*100):(f*100);% ��-128��128�ƽ���ɢʱ�丵��Ҷ�任 
           w=(pi/100)*k;  %ת��Ϊ˫���� ���⻭ͼʱ�������������Ͳ�һ����
           X=x*(exp(-1i*pi/100)).^(n'*k);
           angX=angle(X);
            axes(handles.axes3);
            plot(w,angX);
%             plot(t,abs(g));
            grid on;
            axis([e f  -pi pi]);
           set(gca,'YTick',-pi:pi/2:pi);
           set(gca,'ytickLabel',{'-��','-��/2','0','��/2','��'});
         
    case 4
         if (isempty(a)||isempty(b)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
        t=e:0.01:f;
        x=square(t,100*b/pi);
        y=a*0.5*(x+1);
        axes(handles.axes3);
        plot(t,angle(y));
        axis([e f -pi pi]);
        set(gca,'YTick',-pi:pi/2:pi);
        set(gca,'ytickLabel',{'-��','-��/2','0','��/2','��'});
        grid on;
    case 5
         if (isempty(a)||isempty(b)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
             n=0:128;
             if(b==0||a==0)
               errordlg('a and b must not be 0','warn');
               return;
             end 
           x=a*exp(-b*n);
           k=(e*100):(f*100);
           w=(pi/100)*k;
           X=x*(exp(-1i*pi/100)).^(n'*k);
            angX=angle(X);
            axes(handles.axes3);
            plot(w,angX);
            grid on;
            axis([e f -pi pi]);
           set(gca,'YTick',-pi:pi/2:pi);
           set(gca,'ytickLabel',{'-��','-��/2','0','��/2','��'});
    case 6
         if (isempty(b)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
            guidata(hObject, handles);
           if b >= 0
               n=-b:b;
               x=a*((n+b)>=0&(n-b)<0); % n = b ʱֵӦΪ0
           else
               n=b:-b;
               x=-a*((n+b)<0&(n-b)>=0);
           end
%             n=-b:b;
%             x=a*((n+b)>=0&(n-b)<=0);
            k=(e*100):(f*100);
            w=(pi/100)*k;
            X=x*(exp(-1i*pi/100)).^(n'*k);
            angX=angle(X);
            axes(handles.axes3);
            plot(w,angX);
            grid on;
           axis([e f -pi pi]);
           set(gca,'YTick',-pi:pi/2:pi);
           set(gca,'ytickLabel',{'-��','-��/2','0','��/2','��'});
    case 7
         if (isempty(a)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
            guidata(hObject, handles);
            n=0:128;
              if(a>=1||a<=0)
               errordlg('a must be positive and less than 1','warn');
               return;
              end 
            x=(n+1).*a.^n.*(n>=0);
            k=(e*100):(f*100);
            w=(pi/100)*k;
            X=x*(exp(-1i*pi/100)).^(n'*k);
            angX=angle(X);
            axes(handles.axes3);
            plot(w,angX);
             grid on;
             axis([e f -pi pi]);
           set(gca,'YTick',-pi:pi/2:pi);
           set(gca,'ytickLabel',{'-��','-��/2','0','��/2','��'});
     case 8
         if (isempty(e)||isempty(f))
           errordlg('input error,please check','care');
            return;
         end
         syms n f1(n)
         f1 = eval(get(handles.edit9,'String'));
         t = -128:128;
         f1 = subs(f1,n,t);  %���ű����滻
         f1 = double(f1); %ת����double����
         k=(e*100):(f*100);
         w=(pi/100)*k;
         X=f1*(exp(-1i*pi/100)).^(t'*k);
         angX=angle(X);
         axes(handles.axes3);
         plot(w,angX);
         axis([e f (min(angX) - 1) (max(angX) + 1)]); 
end
 

% --- Executes on button press in pushbutton3.ʱ��
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
a = str2num(get(handles.aINPUT,'String'));
b = str2num(get(handles.bINPUT,'String'));
choose1 = get(handles.popupmenu1,'value');
c = str2num(get(handles.DTmininput,'String'));%ʱ��Χ
d = str2num(get(handles.DTmaxinput,'String'));
if (isempty(a)||isempty(c)||isempty(d))
     c=-10;
     d=10;
 end
switch choose1
    case 1
         if (isempty(a)||isempty(c)||isempty(d))
       errordlg('input error,please check','care');
            return;
         end
         if (abs(a)>1||abs(a)==1)
       errordlg('a must be less than 1','care');
            return;
         end
        guidata(hObject, handles);
        n=(fix(c)-1):(fix(d)+1);
        x=(n>=0).*(a.^n);
        axes(handles.DT);
        stem(n,x);
        axis([c d 0.8.*min(x) 1.2.*max(x)]);
        grid on;
    case 2
         if (isempty(b)||isempty(c)||isempty(d))
       errordlg('input error,please check','care');
            return;
         end
     if (fix(b)~=b)
             errordlg('b must be integer');
             return;
     end
         guidata(hObject, handles);
         n=(fix(c)-1):(fix(d)+1);
         x=(n==b);
         axes(handles.DT);
         stem(n,x);
         axis([c d 0.8.*min(x) 1.2.*max(x)]);
         grid on;
    case 3
         if (isempty(a)||isempty(c)||isempty(d))
            errordlg('input error,please check','care');
            return;
         end
         if (abs(a)>1||abs(a)==1)
       errordlg('a must be less than 1','care');
            return;
         end
         guidata(hObject, handles);
         n=(fix(c)-1):(fix(d)+1);
         x=a.^abs(n);
         axes(handles.DT);
         stem(n,x);
        axis([c d 0.8.*min(x) 1.2.*max(x)]);
         grid on;
    case 4
         if (isempty(a)||isempty(b)||isempty(c)||isempty(d))
       errordlg('input error,please check','care');
            return;
         end
         guidata(hObject, handles);
         n=(fix(c)-1):(fix(d)+1);
         x=a*sin(b*n)./(pi*n); 
         axes(handles.DT);
         stem(n,x);
%        axis([c d -2 a*b/pi+3]);
         axis([c-1 d+1 1.4.*min(x) 1.2.*a*b/pi]);%��������ϵ
         hold on;
         n=0:0;
         x=a*b/pi*(n==0); %��������n = 0�����
         stem(n,x);
         hold off;
         grid on;
         
    case 5
         if (isempty(a)||isempty(b)||isempty(c)||isempty(d))
            errordlg('input error,please check','care');
            return;
         end
         guidata(hObject, handles);
          n=(fix(c)-1):(fix(d)+1);
          x=a*heaviside(n).*exp(-b*n);
          axes(handles.DT);
          stem(n,x);
          axis([c d (min(x)-0.1.*a) (max(x).*1.2)]);
          grid on;
         
    case 6
         if (isempty(a)||isempty(b)||isempty(c)||isempty(d))
           errordlg('input error,please check','care');
            return;
         end
         if (fix(b)~=b)
             errordlg('b must be integer');
             return;
         end
           guidata(hObject, handles);
           n=(fix(c)-1):(fix(d)+1);
           if b >= 0
               x=a*((n+b)>=0&(n-b)<0); % n = b ʱֵӦΪ0
           else
               x=-a*((n+b)<0&(n-b)>=0);
           end
           axes(handles.DT);
           stem(n,x);
%          axis([c d floor(min(x)-1) 1.2*a]);
          
           axis([c d (min(x)-min(1,0.5*a)) 1.2*a]);
            
           grid on;
    case 7
         if (isempty(a)||isempty(c)||isempty(d))
           errordlg('input error,please check','care');
            return;
         end
          if(a>=1||a<=0)
               errordlg('a must be positive and less than 1','warn');
               return;
          end 
           guidata(hObject, handles);
           n=(fix(c)-1):(fix(d)+1);
           x=(n+1).*a.^n.*(n>=0);
           axes(handles.DT);
           stem(n,x);
           axis([c d -a 1.2*max(x)]);
           grid on;
    case 8 
         if (isempty(c)||isempty(d))
           errordlg('input error,please check','care');
            return;
         end
         syms n f(n)
         f = eval(get(handles.edit9,'String'));
         t = c:d;
         f = subs(f,n,t);  %���ű����滻
         axes(handles.DT);
         stem(t,f);
         axis([c d (min(double(f)) -1) (max(double(f)) + 1)]); %���������᷶Χ��������  ʹ��class����fΪsym������Ҫת������ֵ����
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�ɱ༭�����ʼ��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   
%   ainput          �������a
%   binput          �������b
%   DTmininput      ʱ������С��ʾ��Χ
%   DTmaxinput      ʱ���������ʾ��Χ
%   DTFTmagmin      ��Ƶ��Ӧ������С��ʾ��Χ
%   DTFTmagmax      ��Ƶ��Ӧ���������ʾ��Χ
%   DTFTangmin      ��Ƶ��Ӧ������С��ʾ��Χ
%   DTFTangmax      ��Ƶ��Ӧ���������ʾ��Χ
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function aINPUT_Callback(hObject, eventdata, handles)
% hObject    handle to aINPUT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of aINPUT as text
%        str2double(get(hObject,'String')) returns contents of aINPUT as a double


% --- Executes during object creation, after setting all properties.
function aINPUT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to aINPUT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function bINPUT_Callback(hObject, eventdata, handles)
% hObject    handle to bINPUT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bINPUT as text
%        str2double(get(hObject,'String')) returns contents of bINPUT as a double

% --- Executes during object creation, after setting all properties.
function bINPUT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bINPUT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function DTFTmagmax_Callback(hObject, eventdata, handles)
% hObject    handle to DTFTmagmax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of DTFTmagmax as text
%        str2double(get(hObject,'String')) returns contents of DTFTmagmax as a double


% --- Executes during object creation, after setting all properties.
function DTFTmagmax_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DTFTmagmax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function DTFTmagmin_Callback(hObject, eventdata, handles)
% hObject    handle to DTFTmagmin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of DTFTmagmin as text
%        str2double(get(hObject,'String')) returns contents of DTFTmagmin as a double


% --- Executes during object creation, after setting all properties.
function DTFTmagmin_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DTFTmagmin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function DTFTangmax_Callback(hObject, eventdata, handles)
% hObject    handle to DTFTangmax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of DTFTangmax as text
%        str2double(get(hObject,'String')) returns contents of DTFTangmax as a double


% --- Executes during object creation, after setting all properties.
function DTFTangmax_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DTFTangmax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function DTFTangmin_Callback(hObject, eventdata, handles)
% hObject    handle to DTFTangmin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of DTFTangmin as text
%        str2double(get(hObject,'String')) returns contents of DTFTangmin as a double


% --- Executes during object creation, after setting all properties.
function DTFTangmin_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DTFTangmin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function DTmaxinput_Callback(hObject, eventdata, handles)
% hObject    handle to DTmaxinput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of DTmaxinput as text
%        str2double(get(hObject,'String')) returns contents of DTmaxinput as a double


% --- Executes during object creation, after setting all properties.
function DTmaxinput_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DTmaxinput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function DTmininput_Callback(hObject, eventdata, handles)
% hObject    handle to DTmininput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of DTmininput as text
%        str2double(get(hObject,'String')) returns contents of DTmininput as a double


% --- Executes during object creation, after setting all properties.
function DTmininput_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DTmininput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function shiziINPUT_Callback(hObject, eventdata, handles)
% hObject    handle to shiziINPUT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of shiziINPUT as text
%        str2double(get(hObject,'String')) returns contents of shiziINPUT as a double


% --- Executes during object creation, after setting all properties.
function shiziINPUT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to shiziINPUT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%����ʽ�˵���ʼ��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1

% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�˵����ó�ʼ��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --------------------------------------------------------------------
%       menu           �˵�����
%       help           �����ĵ��Ӳ˵�����
%       DTplot         ʱ���ο�ݼ�����
%       DTFTmag        ��Ƶ��Ӧ���ο�ݼ�����
%       DTFTang        ��Ƶ��Ӧ���ο�ݼ�����  
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function menu_Callback(hObject, eventdata, handles)
% hObject    handle to menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --------------------------------------------------------------------
function help_Callback(hObject, eventdata, handles)
% hObject    handle to help (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
str={'    ע�⣺��ִ�л�ͼ����ǰҪ��a��b�����Լ���ʾ���䳤�����ú�(Ĭ��Ϊ-pi��pi)x������Ҫ��pi',...
     '����ᱨ��,��Σ��ڳ弤�����ͽ�Ծ������bΪ������',...
     '    ����Ϊ����С���飺',...
     '',...
     '1.a������ֵҪ���ݱ���ʽ����������',...
     '2.��Ƶ����Ƶ��Ӧ�н������䳤��ȡ2����-1��1',...
     '3.���������������ĸ��������䳤�ȿ���ȡ��һ����ڹ۲�',...
     ' ������Ҫ�������䳤��',...
     '4.�ڵ���������У�b��ȡֵ��Ҫ���󣬽���ȡb<1,�����β�����',... 
     };
 h = msgbox(str,'��ɢ����Ҷ�任�����ĵ�');
% set(h,'Resize','on');
% set(h,'Position',[100 100 500 500]);

% --------------------------------------------------------------------
function DTplot_Callback(hObject, eventdata, handles)
% hObject    handle to DT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
a = str2num(get(handles.aINPUT,'String'));
 b = str2num(get(handles.bINPUT,'String'));
 choose1 = get(handles.popupmenu1,'value');
 c = str2num(get(handles.DTmininput,'String'));
 d = str2num(get(handles.DTmaxinput,'String'));
if (isempty(a)||isempty(c)||isempty(d))
     c=-10;
     d=10;
 end
switch choose1
    case 1
         if (isempty(a)||isempty(c)||isempty(d))
       errordlg('input error,please check','care');
            return;
         end
         if (abs(a)>1||abs(a)==1)
       errordlg('a must be less than 1','care');
            return;
         end
        guidata(hObject, handles);
        n=(fix(c)-1):(fix(d)+1);
        x=(n>=0).*(a.^n);
        axes(handles.DT);
        stem(n,x);
        axis([c d 0.8.*min(x) 1.2.*max(x)]);
        grid on;
    case 2
         if (isempty(b)||isempty(c)||isempty(d))
       errordlg('input error,please check','care');
            return;
         end
     if (fix(b)~=b)
             errordlg('b must be integer');
             return;
     end
         guidata(hObject, handles);
         n=(fix(c)-1):(fix(d)+1);
         x=(n==b);
         axes(handles.DT);
         stem(n,x);
         axis([c d 0.8.*min(x) 1.2.*max(x)]);
         grid on;
    case 3
         if (isempty(a)||isempty(c)||isempty(d))
            errordlg('input error,please check','care');
            return;
         end
         if (abs(a)>1||abs(a)==1)
       errordlg('a must be less than 1','care');
            return;
         end
         guidata(hObject, handles);
         n=(fix(c)-1):(fix(d)+1);
         x=a.^abs(n);
         axes(handles.DT);
         stem(n,x);
        axis([c d 0.8.*min(x) 1.2.*max(x)]);
         grid on;
    case 4
         if (isempty(a)||isempty(b)||isempty(c)||isempty(d))
       errordlg('input error,please check','care');
            return;
         end
         guidata(hObject, handles);
         n=(fix(c)-1):(fix(d)+1);
         x=a*sin(b*n)./(pi*n); 
         axes(handles.DT);
         stem(n,x);
%        axis([c d -2 a*b/pi+3]);
         axis([c-1 d+1 1.4.*min(x) 1.2.*a*b/pi]);%��������ϵ
         hold on;
         n=0:0;
         x=a*b/pi*(n==0); %��������n = 0�����
         stem(n,x);
         hold off;
         grid on;
         
    case 5
         if (isempty(a)||isempty(b)||isempty(c)||isempty(d))
            errordlg('input error,please check','care');
            return;
         end
         guidata(hObject, handles);
          n=(fix(c)-1):(fix(d)+1);
          x=a*heaviside(n).*exp(-b*n);
          axes(handles.DT);
          stem(n,x);
          axis([c d (min(x)-0.1.*a) (max(x).*1.2)]);
          grid on;
         
    case 6
         if (isempty(a)||isempty(b)||isempty(c)||isempty(d))
           errordlg('input error,please check','care');
            return;
         end
         if (fix(b)~=b)
             errordlg('b must be integer');
             return;
         end
           guidata(hObject, handles);
           n=(fix(c)-1):(fix(d)+1);
           if b >= 0
               x=a*((n+b)>=0&(n-b)<0); % n = b ʱֵӦΪ0
           else
               x=-a*((n+b)<0&(n-b)>=0);
           end
           axes(handles.DT);
           stem(n,x);
%          axis([c d floor(min(x)-1) 1.2*a]);
          
           axis([c d (min(x)-min(1,0.5*a)) 1.2*a]);
            
           grid on;
    case 7
         if (isempty(a)||isempty(c)||isempty(d))
           errordlg('input error,please check','care');
            return;
         end
          if(a>=1||a<=0)
               errordlg('a must be positive and less than 1','warn');
               return;
          end 
           guidata(hObject, handles);
           n=(fix(c)-1):(fix(d)+1);
           x=(n+1).*a.^n.*(n>=0);
           axes(handles.DT);
           stem(n,x);
           axis([c d -a 1.2*max(x)]);
           grid on;
    case 8 
         if (isempty(c)||isempty(d))
           errordlg('input error,please check','care');
            return;
         end
         syms n f(n)
         f = eval(get(handles.shiziINPUT,'String'));
         t = c:d;
         f = subs(f,n,t);  %���ű����滻
         axes(handles.DT);
         stem(t,f);
         axis([c d (min(double(f)) -1) (max(double(f)) + 1)]); %���������᷶Χ��������  ʹ��class����fΪsym������Ҫת������ֵ����
end


% --------------------------------------------------------------------
function DTFTmag_Callback(hObject, eventdata, handles)
% hObject    handle to DTFTmag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
a = str2num(get(handles.aINPUT,'String'));
 b = str2num(get(handles.bINPUT,'String'));
 choose1 = get(handles.popupmenu1,'value');
 e = str2num(get(handles.DTFTmagmin,'String'));
 f = str2num(get(handles.DTFTmagmax,'String'));
if (isempty(a)||isempty(e)||isempty(f))
     e=-pi;
     f=pi;
 end
switch choose1
    case 1
         if (isempty(a)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
         if (abs(a)>1||abs(a)==1)
       errordlg('a must be less than 1','care');
            return;
         end
           guidata(hObject, handles);
%            syms x n;
           if(a>1)
               errordlg('a must less than 1','warn');
               return;
           end    
%            s1=a.^n*exp(-1i*x*n);
%            m=symsum(s1,n,0,inf); %��ͼ��㸵��Ҷ�任(����)  ����ʱ��̫������ȡ
            t=e:0.01:f;
%            g=subs(m,x,t);
            g = 1./(1-a*exp(-1i*t));
           axes(handles.axes2);
           plot(t,abs(g));  
           h=abs(g);
           axis([e f 0.5*min(h) max(h)*1.2]);
           grid on
         
    case 2
         if (isempty(b)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
         guidata(hObject, handles);
         if (fix(b)~=b)
             errordlg('b must be integer');
             return;
         end
         w=e:0.01:f;
         x=exp(-1i*w*b);
         axes(handles.axes2);
         plot(w,abs(x));
         axis([e f min(abs(x))-1 max(abs(x))+1]);
         grid on;
         
    case 3
         if (isempty(a)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
           guidata(hObject, handles);
           n=-128:128;
          if(a>=1||a<=0)
               errordlg('a must be positive and less than 1','warn');
               return;
          end 
%            syms x n;
%            s1=a.^abs(n)*exp(-1i*x*n);
%            m=symsum(s1,n,-inf,inf); %��ͼ��㸵��Ҷ�任  ����ʱ��̫������ȡ
%            t=e:0.01:f;
%            g=subs(m,x,t);
           x=a.^abs(n);
           k=(e*100):(f*100);% ��-128��128�ƽ���ɢʱ�丵��Ҷ�任 
           w=(pi/100)*k;  %ת��Ϊ˫���� ���⻭ͼʱ�������������Ͳ�һ����
           X=x*(exp(-1i*pi/100)).^(n'*k);
           magX=abs(X);
            axes(handles.axes2);
            plot(w,magX);
%             plot(t,abs(g));
            grid on;
            axis([e f -0.5 (1+a)/(1-a)+3]);
         
    case 4
         if (isempty(a)||isempty(b)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
        t=e:0.01:f;
        x=square(t,100*b/pi);%b���ܴ���pi
        y=a*0.5*(x+1);
        axes(handles.axes2);
        plot(t,y);
        axis([e f -1 a.*2.2]);
        grid on;
    case 5
         if (isempty(a)||isempty(b)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
             n=0:128;
             if(b==0||a==0)
               errordlg('a and b must not be 0','warn');
               return;
             end 
           x=a*exp(-b*n);
           k=(e*100):(f*100);
           w=(pi/100)*k;
           X=x*(exp(-1i*pi/100)).^(n'*k);
            magX=abs(X);
            axes(handles.axes2);
            plot(w,magX);
            grid on;
            axis([e f -0.1.*max(magX) max(magX).*1.2]);%Ϊ�˸��ù۲�ͼ�񣬽���b������1
    case 6
         if (isempty(b)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
            guidata(hObject, handles);
           if b >= 0
               n=-b:b;
               x=a*((n+b)>=0&(n-b)<0); % n = b ʱֵӦΪ0
           else
               n=b:-b;
               x=-a*((n+b)<0&(n-b)>=0);
           end
%             n=-b:b;
%             x=a*((n+b)>=0&(n-b)<=0);
            k=(e*100):(f*100);
            w=(pi/100)*k;
            X=x*(exp(-1i*pi/100)).^(n'*k);
            magX=abs(X);
            axes(handles.axes2);
            plot(w,magX);
            grid on;
           axis([e f floor(min(magX)-1) max(magX)+2]);
    case 7
         if (isempty(a)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
            guidata(hObject, handles);
            n=0:128;
              if(a>=1||a<=0)
               errordlg('a must be positive and less than 1','warn');
               return;
              end 
            x=(n+1).*a.^n.*(n>=0);
            k=(e*100):(f*100);
            w=(pi/100)*k;
            X=x*(exp(-1i*pi/100)).^(n'*k);
            magX=abs(X);
            axes(handles.axes2);
            plot(w,magX);
             grid on;% ����ֻ��һ�����ڣ���Ƶ�ʷ�ΧΪ-1��1
             axis([e f -1 max(magX).*1.2]);
    case 8  
         if (isempty(e)||isempty(f))
           errordlg('input error,please check','care');
            return;
         end
         syms n f1(n)
         f1 = eval(get(handles.edit9,'String'));
         t = -128:128;
         f1 = subs(f1,n,t);  %���ű����滻
         f1 = double(f1); %ת����double����
         k=(e*100):(f*100);
         w=(pi/100)*k;
         X=f1*(exp(-1i*pi/100)).^(t'*k);
         magX=abs(X);
         axes(handles.axes2);
         plot(w,magX);
         axis([e f (min(magX) - 1) (max(magX) + 1)]); 
end


% --------------------------------------------------------------------
function DTFTang_Callback(hObject, eventdata, handles)
% hObject    handle to DTFTang (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
a = str2num(get(handles.aINPUT,'String'));
b = str2num(get(handles.bINPUT,'String'));
 choose1 = get(handles.popupmenu1,'value');
 e = str2num(get(handles.DTFTangmin,'String'));%��Ƶ��Χ
 f = str2num(get(handles.DTFTangmax,'String'));
 if (isempty(a)||isempty(e)||isempty(f))
     e=-pi;
     f=pi;
 end
 switch choose1
    case 1
         if (isempty(a)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
          if (abs(a)>1||abs(a)==1)
       errordlg('a must be less than 1','care');
            return;
         end
           guidata(hObject, handles);
%            syms x n;
           if(a>1)
               errordlg('a must less than 1','warn');
               return;
           end    
%            s1=a.^n*exp(-1i*x*n);
%            m=symsum(s1,n,0,inf); %��ͼ��㸵��Ҷ�任(����)  ����ʱ��̫������ȡ
            t=e:0.01:f;
%            g=subs(m,x,t);
            g = 1./(1-a*exp(-1i*t));
           axes(handles.axes3);
           plot(t,angle(g));  
           axis([e f -pi pi]);
           set(gca,'YTick',-pi:pi/2:pi);
           set(gca,'ytickLabel',{'-��','-��/2','0','��/2','��'});
           grid on
         
    case 2
         if (isempty(b)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
         guidata(hObject, handles);
         if (fix(b)~=b)
             errordlg('b must be integer');
             return;
         end
         w=e:0.01:f;
         x=exp(-1i*w*b);
         axes(handles.axes3);
         plot(w,angle(x));
         axis([e f -pi pi]);
         set(gca,'YTick',-pi:pi/2:pi);
         set(gca,'ytickLabel',{'-��','-��/2','0','��/2','��'});
         grid on;
         
    case 3
         if (isempty(a)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
           guidata(hObject, handles);
           n=-128:128;
          if(a>=1||a<=0)
               errordlg('a must be positive and less than 1','warn');
               return;
          end 
%            syms x n;
%            s1=a.^abs(n)*exp(-1i*x*n);
%            m=symsum(s1,n,-inf,inf); %��ͼ��㸵��Ҷ�任  ����ʱ��̫������ȡ
%            t=e:0.01:f;
%            g=subs(m,x,t);
           x=a.^abs(n);
           k=(e*100):(f*100);% ��-128��128�ƽ���ɢʱ�丵��Ҷ�任 
           w=(pi/100)*k;  %ת��Ϊ˫���� ���⻭ͼʱ�������������Ͳ�һ����
           X=x*(exp(-1i*pi/100)).^(n'*k);
           angX=angle(X);
            axes(handles.axes3);
            plot(w,angX);
%             plot(t,abs(g));
            grid on;
            axis([e f  -pi pi]);
           set(gca,'YTick',-pi:pi/2:pi);
           set(gca,'ytickLabel',{'-��','-��/2','0','��/2','��'});
         
    case 4
         if (isempty(a)||isempty(b)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
        t=e:0.01:f;
        x=square(t,100*b/pi);
        y=a*0.5*(x+1);
        axes(handles.axes3);
        plot(t,angle(y));
        axis([e f -pi pi]);
        set(gca,'YTick',-pi:pi/2:pi);
        set(gca,'ytickLabel',{'-��','-��/2','0','��/2','��'});
        grid on;
    case 5
         if (isempty(a)||isempty(b)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
             n=0:128;
             if(b==0||a==0)
               errordlg('a and b must not be 0','warn');
               return;
             end 
           x=a*exp(-b*n);
           k=(e*100):(f*100);
           w=(pi/100)*k;
           X=x*(exp(-1i*pi/100)).^(n'*k);
            angX=angle(X);
            axes(handles.axes3);
            plot(w,angX);
            grid on;
            axis([e f -pi pi]);
           set(gca,'YTick',-pi:pi/2:pi);
           set(gca,'ytickLabel',{'-��','-��/2','0','��/2','��'});
    case 6
         if (isempty(b)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
            guidata(hObject, handles);
           if b >= 0
               n=-b:b;
               x=a*((n+b)>=0&(n-b)<0); % n = b ʱֵӦΪ0
           else
               n=b:-b;
               x=-a*((n+b)<0&(n-b)>=0);
           end
%             n=-b:b;
%             x=a*((n+b)>=0&(n-b)<=0);
            k=(e*100):(f*100);
            w=(pi/100)*k;
            X=x*(exp(-1i*pi/100)).^(n'*k);
            angX=angle(X);
            axes(handles.axes3);
            plot(w,angX);
            grid on;
           axis([e f -pi pi]);
           set(gca,'YTick',-pi:pi/2:pi);
           set(gca,'ytickLabel',{'-��','-��/2','0','��/2','��'});
    case 7
         if (isempty(a)||isempty(e)||isempty(f))
       errordlg('input error,please check','care');
            return;
         end
            guidata(hObject, handles);
            n=0:128;
              if(a>=1||a<=0)
               errordlg('a must be positive and less than 1','warn');
               return;
              end 
            x=(n+1).*a.^n.*(n>=0);
            k=(e*100):(f*100);
            w=(pi/100)*k;
            X=x*(exp(-1i*pi/100)).^(n'*k);
            angX=angle(X);
            axes(handles.axes3);
            plot(w,angX);
             grid on;
             axis([e f -pi pi]);
           set(gca,'YTick',-pi:pi/2:pi);
           set(gca,'ytickLabel',{'-��','-��/2','0','��/2','��'});
     case 8
         if (isempty(e)||isempty(f))
           errordlg('input error,please check','care');
            return;
         end
         syms n f1(n)
         f1 = eval(get(handles.edit9,'String'));
         t = -128:128;
         f1 = subs(f1,n,t);  %���ű����滻
         f1 = double(f1); %ת����double����
         k=(e*100):(f*100);
         w=(pi/100)*k;
         X=f1*(exp(-1i*pi/100)).^(t'*k);
         angX=angle(X);
         axes(handles.axes3);
         plot(w,angX);
         axis([e f (min(angX) - 1) (max(angX) + 1)]); 
end
  
% --------------------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% --------------------------------------------------------------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%����һЩ������ʼ��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ĳЩ����û�и�����ʼ��
% --- Executes during object creation, after setting all properties.
function DT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: place code in OpeningFcn to populate DT
% --- Executes during object creation, after setting all properties.
function axes2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes2

% --- Executes during object creation, after setting all properties.
function axes3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%������������%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%       pushbutton4       ���ذ�������    
%       pushbutton5       �����������
%       pushbutton6       ȫ���������
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close gcf;
mystart;


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
delete(allchild(handles.DT));
delete(allchild(handles.axes2));
delete(allchild(handles.axes3));


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
delete(allchild(handles.DT));
delete(allchild(handles.axes2));
delete(allchild(handles.axes3));
set(handles.aINPUT,'string','');
set(handles.bINPUT,'string','');
set(handles.DTmininput,'string','');
set(handles.DTmaxinput,'string','');
set(handles.DTFTmagmin,'string','');
set(handles.DTFTmagmax,'string','');
set(handles.DTFTangmin,'string','');
set(handles.DTFTangmax,'string','');
