 function varargout = continuous_system(varargin)
% CONTINUOUS_SYSTEM MATLAB code for continuous_system.fig
%      CONTINUOUS_SYSTEM, by itself, creates a new CONTINUOUS_SYSTEM or raises the existing
%      singleton*.
%
%      H = CONTINUOUS_SYSTEM returns the handle to a new CONTINUOUS_SYSTEM or the handle to
%      the existing singleton*.
%
%      CONTINUOUS_SYSTEM('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CONTINUOUS_SYSTEM.M with the given input arguments.
%
%      CONTINUOUS_SYSTEM('Property','Value',...) creates a new CONTINUOUS_SYSTEM or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before continuous_system_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to continuous_system_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help continuous_system

% Last Modified by GUIDE v2.5 22-Dec-2020 16:50:24

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @continuous_system_OpeningFcn, ...
                   'gui_OutputFcn',  @continuous_system_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before continuous_system is made visible.
function continuous_system_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to continuous_system (see VARARGIN)

% Choose default command line output for continuous_system
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes continuous_system wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = continuous_system_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function menu_Callback(hObject, eventdata, handles)
% hObject    handle to menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function help_Callback(hObject, eventdata, handles)
%�ṩ�����ĵ�
% hObject    handle to help (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
str ={ '    ���Ǹ������ĵ�,�ڲ˵��п����ٴδ�',...
    '',...
    '    1���������ı����ﰴ�ա����ݡ�˳������ϵͳ������ĸ�����ϵ�����ұ�֤���Ӻͷ�ĸϵ���ĸ�����ͬ��',...
    '����(s^2+s+1)/s:��������1��1��1������ĸ����0,1,0�����벻��Ϊ��',...
    '    2��������ͨ������˵�ѡ����߰�ť��ѡ�����ϵͳ�����ķ�Ƶ��Ӧ|H(jw)|�Լ���Ƶ��Ӧarg(H(jw))��',...
    'ͬʱ�����Զ�����۲�ͼ��ķ�Χ�����磬0��10Hz����0��10',...
    '    3������ͨ���������������ͼ�������룬������ص�������',...
    '    4����ݼ�Ctrl+a Ctrl+g Ctrl+zҲ���Ի��Ʒ�Ƶ����Ƶ������ͼ'};
h = msgbox(str,'����ϵͳ�����ĵ�');

% --------------------------------------------------------------------
function amplitude_Callback(hObject, eventdata, handles)
%���Ʒ�Ƶ��������
% hObject    handle to amplitude (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
num=str2num(get(handles.edit1,'String'));
den=str2num(get(handles.edit2,'String'));
if isempty(num)
    msgbox('numerator should not be empty','warn','warn');
    return
end
if isempty(den)
    msgbox('denominator should not be empty','warn','warn');
    return
end
axes(handles.axes2);
[Hs,W]=freqs(num,den);
magh=abs(Hs);%ȡģ
zerosIndx=find(magh==0);%�ҵ�ģΪ0�ĵ㽫����һ������ȡ������������
magh(zerosIndx)=1;
magh=20*log10(magh);
magh(zerosIndx)=-inf;
plot(W,magh);
xlabel('w');
ylabel('��Ƶ��Ӧ dB');
grid on
try
freqrange=str2num(get(handles.edit3,'string'));%��ȡ�������귶
xlim(freqrange)
yrange=str2num(get(handles.edit4,'string'));
ylim(yrange);
end




% --------------------------------------------------------------------
function angle_Callback(hObject, eventdata, handles)
%������Ƶ��������
% hObject    handle to angle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
num=str2num(get(handles.edit1,'String'));
den=str2num(get(handles.edit2,'String'));
if isempty(num)
    msgbox('numerator should not be empty','warn','warn');
    return
end
if isempty(den)
    msgbox('denominator should not be empty','warn','warn');
    return
end
axes(handles.axes3);
[Hs,W]=freqs(num,den);%��ȡ���ϱ任���Ƶ����Ӧ����
W=W./pi;%��һ��
angh=angle(Hs);%��ȡ�Ƕ�
angh=unwrap(angh);%���ɻ�����
plot(W,angh);%���ƽǶ�
xlabel('w/pi');
ylabel('��Ƶ��ӦRAD');
grid on
try
freqrange=str2num(get(handles.edit5,'string'));%��ȡ�������귶Χ
xlim(freqrange);
yrange=str2num(get(handles.edit6,'string'));
ylim(yrange);
end


% --------------------------------------------------------------------
function jilingtu_Callback(hObject, eventdata, handles)
%���Ƽ���ͼ
% hObject    handle to jilingtu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
num=str2num(get(handles.edit1,'String'));
den=str2num(get(handles.edit2,'String'));
ROC=get(handles.checkbox4,'value');
%�жϱ߽�����
if isempty(num)
    msgbox('numerator should not be empty','warn','warn');
    return
end
if isempty(den)
    msgbox('denominator should not be empty','warn','warn');
    return
end
Hs=tf(num,den);%���ݸ����ķ��ӷ�ĸ��������ʽ
[p,z]=pzmap(Hs);%����ϵͳ�ļ�������
%zplane(z,p);%���Ƽ���ͼ
pn=length(p);

axes(handles.axes1);
plot(real(z),imag(z),'o',real(p),imag(p),'kx');
axis([-2,2,-2,2]);
xlabel('ʵ��');
ylabel('�鲿');
grid on

for i=1:length(p)
    if (real(p(i))>=0&&ROC==1)||(real(p(i))<=0&&ROC==2)%��������������򲻰���jw�ᣬϵͳ���ȶ�
         msgbox('��ϵͳ�ǲ��ȶ��ģ�','Tips','help','modal');
    elseif i==(length(p))
         msgbox('��ϵͳ���ȶ��ģ�','Tips','help','modal');
    end
end



% ���Ʒ�Ƶ��������
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
num=str2num(get(handles.edit1,'String'));
den=str2num(get(handles.edit2,'String'));
if isempty(num)
    msgbox('numerator should not be empty','warn','warn');
    return
end
if isempty(den)
    msgbox('denominator should not be empty','warn','warn');
    return
end
axes(handles.axes2);
[Hs,W]=freqs(num,den);
magh=abs(Hs);%ȡģ
zerosIndx=find(magh==0);%�ҵ�ģΪ0�ĵ㽫����һ������ȡ������������
magh(zerosIndx)=1;
magh=20*log10(magh);
magh(zerosIndx)=-inf;
plot(W,magh);
xlabel('w');
ylabel('��Ƶ��Ӧ dB');
grid on
try
freqrange=str2num(get(handles.edit3,'string'));%��ȡ�������귶Χ
xlim(freqrange);
yrange=str2num(get(handles.edit4,'string'));
ylim(yrange);
end




function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% ��������ر�ģ�鴰��
close gcf;
% ��������visible������
mystart;


% --- Executes on button press in checkbox4.
function checkbox4_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox4


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
num=str2num(get(handles.edit1,'String'));
den=str2num(get(handles.edit2,'String'));
shoulianyu=get(handles.checkbox4,'value');
%�жϱ߽�����
if isempty(num)
    msgbox('numerator should not be empty','warn','warn');
    return
end
if isempty(den)
    msgbox('denominator should not be empty','warn','warn');
    return
end
H=tf(num,den);%���ݸ����ķ��ӷ�ĸ��������ʽ
[p,z]=pzmap(H);%����ϵͳ�ļ�������
%zplane(z,p);%���Ƽ���ͼ
pn=length(p);
for i=1:length(p)
    if (real(p(i))>=0&&shoulianyu==1)||(real(p(i))<=0&&shoulianyu==2)
         msgbox('��ϵͳ�ǲ��ȶ��ģ�','Tips','help','modal');
    elseif i==(length(p))
         msgbox('��ϵͳ���ȶ��ģ�','Tips','help','modal');
    end
end
axes(handles.axes1);
plot(real(z),imag(z),'o',real(p),imag(p),'kx');
axis([-2,2,-2,2]);
xlabel('ʵ��');
ylabel('�鲿');
grid on



% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
num=str2num(get(handles.edit1,'String'));
den=str2num(get(handles.edit2,'String'));
if isempty(num)
    msgbox('numerator should not be empty','warn','warn');
    return
end
if isempty(den)
    msgbox('denominator should not be empty','warn','warn');
    return
end
axes(handles.axes3);
[Hs,W]=freqs(num,den);%��ȡ���ϱ任���Ƶ����Ӧ����
W=W./pi;%��һ��
angh=angle(Hs);%��ȡ�Ƕ�
angh=unwrap(angh);%���ɻ�����
plot(W,angh);%���ƽǶ�
xlabel('w/pi');
ylabel('��Ƶ��ӦRAD');
grid on
try
freqrange=str2num(get(handles.edit5,'string'));%��ȡ�������귶Χ
xlim(freqrange);
yrange=str2num(get(handles.edit6,'string'));
ylim(yrange);
end




% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
ha=axes('units','normalized','pos',[0 0 1 1]);
uistack(ha,'bottom');
ii=imread('����.jfif');
image(ii);
colormap gray
set(ha,'handlevisibility','off','visible','off');

function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    delete(allchild(handles.axes1));
    delete(allchild(handles.axes2));
    delete(allchild(handles.axes3));
    set(handles.edit1,'string','');
    set(handles.edit2,'string','');
    set(handles.edit3,'string','');
    set(handles.edit4,'string','');
    set(handles.edit5,'string','');
    set(handles.edit6,'string','');
    set(handles.checkbox4,'value',1);
   
